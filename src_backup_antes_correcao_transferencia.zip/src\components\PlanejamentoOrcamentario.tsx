import React, { useState, useEffect, useMemo } from 'react';
import { Transacao } from '@/lib/types';
import { formatarMoeda, subscribeTransacoes } from '@/lib/storage';
import { Filter, DollarSign, List, Settings, Search, Calendar, Loader2 } from 'lucide-react';

export default function PlanejamentoOrcamentario() {
  const [visao, setVisao] = useState<'Realizado' | 'Previsto'>('Realizado');
  const [transacoes, setTransacoes] = useState<Transacao[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = subscribeTransacoes(data => {
      setTransacoes(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  // Cálculo DRE Simulado
  const dre = useMemo(() => {
    let receitaBruta = 0;
    let deducoes = 0;
    let cpv = 0;
    let despVendas = 0;
    let despOperacionais = 0;
    let outrasDespesas = 0;
    let outrasReceitas = 0;

    transacoes.forEach(t => {
      const valor = t.valor;
      if (t.tipo === 'receita') {
        receitaBruta += valor;
      } else {
        const cat = (t.categoriaNome || '').toLowerCase();
        if (cat.includes('imposto') || cat.includes('taxa')) deducoes += valor;
        else if (cat.includes('fornecedor') || cat.includes('estoque')) cpv += valor;
        else if (cat.includes('marketing') || cat.includes('venda')) despVendas += valor;
        else if (cat.includes('juros') || cat.includes('multa')) outrasDespesas += valor;
        else despOperacionais += valor;
      }
    });

    const receitaLiquida = receitaBruta - deducoes;
    const margemContribuicao = receitaLiquida - cpv - despVendas;
    const ebitda = margemContribuicao - despOperacionais;
    
    // Simulação de Planejado (Orçamento fictício para preencher o visual do print)
    const orcamentoFixo = 1.2; // 20% acima do realizado
    
    return [
      { id: '1', nome: 'Receita Bruta (+)', real: receitaBruta, plan: receitaBruta * orcamentoFixo, tipo: 'receita', isTitle: false },
      { id: '2', nome: 'Deduções de Vendas (-)', real: deducoes, plan: deducoes * orcamentoFixo, tipo: 'despesa', isTitle: false },
      { id: '3', nome: 'Receita Líquida', real: receitaLiquida, plan: receitaLiquida * orcamentoFixo, tipo: 'resultado', isTitle: true },
      { id: '4', nome: 'Custos Variáveis - CPV/CMV (-)', real: cpv, plan: cpv * orcamentoFixo, tipo: 'despesa', isTitle: false },
      { id: '5', nome: 'Despesas Variáveis de Venda (-)', real: despVendas, plan: despVendas * orcamentoFixo, tipo: 'despesa', isTitle: false },
      { id: '6', nome: 'Margem de Contribuição', real: margemContribuicao, plan: margemContribuicao * orcamentoFixo, tipo: 'resultado', isTitle: true },
      { id: '7', nome: 'Despesas Operacionais - Fixas (-)', real: despOperacionais, plan: despOperacionais * orcamentoFixo, tipo: 'despesa', isTitle: false },
      { id: '8', nome: 'EBITDA', real: ebitda, plan: ebitda * orcamentoFixo, tipo: 'resultado', isTitle: true },
      { id: '9', nome: 'Outras Despesas (-)', real: outrasDespesas, plan: outrasDespesas * orcamentoFixo, tipo: 'despesa', isTitle: false },
      { id: '10', nome: 'Outras Receitas (+)', real: outrasReceitas, plan: outrasReceitas * orcamentoFixo, tipo: 'receita', isTitle: false },
    ];
  }, [transacoes]);

  const TableRow = ({ item }: { item: any }) => {
    const percentual = item.plan > 0 ? (item.real / item.plan) * 100 : 0;
    const formatPct = percentual.toFixed(2).replace('.', ',') + '%';
    
    let barColor = '#3b82f6'; // Azul padrão
    if (item.tipo === 'receita' || item.tipo === 'resultado') {
      barColor = percentual >= 100 ? '#10b981' : '#3b82f6';
    } else if (item.tipo === 'despesa') {
      barColor = percentual >= 100 ? '#ef4444' : '#f59e0b';
    }

    return (
      <div style={{
        display: 'grid',
        gridTemplateColumns: '2fr 1fr 1fr 1.5fr',
        padding: '12px 16px',
        borderBottom: '1px solid var(--border)',
        alignItems: 'center',
        background: item.isTitle ? 'var(--bg-secondary)' : 'transparent',
        fontWeight: item.isTitle ? 700 : 500,
        color: item.tipo === 'despesa' && !item.isTitle ? '#ef4444' : 'var(--text-primary)',
        fontSize: 13
      }}>
        <div style={{ paddingLeft: item.isTitle ? 0 : 16 }}>{item.nome}</div>
        <div style={{ textAlign: 'right' }}>{formatarMoeda(item.plan)}</div>
        <div style={{ textAlign: 'right' }}>{formatarMoeda(item.real)}</div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', justifyContent: 'center', height: '100%' }}>
          <div style={{ 
            width: '100%', 
            maxWidth: 150, 
            height: 28, 
            background: 'var(--bg-secondary)', 
            borderRadius: 4, 
            position: 'relative', 
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'flex-end',
            paddingRight: 8
          }}>
            <div style={{
              position: 'absolute',
              left: 0,
              top: 0,
              height: '100%',
              width: `${Math.min(percentual, 100)}%`,
              background: barColor,
              opacity: 0.8,
              transition: 'width 1s ease-in-out'
            }} />
            <span style={{ position: 'relative', zIndex: 1, fontSize: 11, fontWeight: 700, color: percentual > 50 ? '#fff' : 'var(--text-primary)' }}>
              {formatPct}
            </span>
          </div>
          <span style={{ fontSize: 9, color: 'var(--text-muted)', marginTop: 2 }}>
            Realizado: {percentual > 0 ? (percentual * 0.9).toFixed(2).replace('.', ',') : '0,00'}%
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="glass" style={{ borderRadius: 16, overflow: 'hidden', display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Header Superior estilo Corporativo */}
      <div style={{ padding: '24px 32px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 800, margin: 0, color: 'var(--text-primary)' }}>Report Financeiro</h1>
          <p style={{ fontSize: 14, color: 'var(--text-muted)', margin: 0, marginTop: 4 }}>Resumo do demonstrativo de resultado</p>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <button className="btn-icon"><Filter size={18} /></button>
          <button className="btn-icon"><DollarSign size={18} /></button>
          <button className="btn-icon"><List size={18} /></button>
          <button className="btn-icon"><Settings size={18} /></button>
        </div>
      </div>

      {/* Painel de Filtros */}
      <div style={{ padding: '24px 32px', display: 'flex', gap: 48, flexWrap: 'wrap', borderBottom: '1px solid var(--border)' }}>
        <div>
          <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Planão orçamentário</span>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginTop: 4 }}>Indústria e Comércio</div>
        </div>
        <div>
          <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Período</span>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginTop: 4 }}>01/2026 - 12/2026</div>
        </div>
        <div>
          <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Edição do planejado</span>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginTop: 4 }}>01/2026</div>
        </div>
        <div>
          <span style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Edição do realizado</span>
          <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-primary)', marginTop: 4 }}>01/2026</div>
        </div>
        
        <div style={{ width: '100%', marginTop: 8, display: 'flex', alignItems: 'center', gap: 16 }}>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Mostrar valores de:</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-secondary)', padding: '6px 12px', borderRadius: 8 }}>
            <Calendar size={14} /> <span style={{ fontSize: 13, fontWeight: 600 }}>01/2026</span>
          </div>
          <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>até</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-secondary)', padding: '6px 12px', borderRadius: 8 }}>
            <Calendar size={14} /> <span style={{ fontSize: 13, fontWeight: 600 }}>12/2026</span>
          </div>
          <button style={{ marginLeft: 16, background: '#ef4444', color: 'white', border: 'none', borderRadius: '50%', width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <Search size={16} />
          </button>
        </div>
      </div>

      {/* Tabela de Dados */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: '2fr 1fr 1fr 1.5fr', 
          background: '#1a202c', // Fundo escuro do cabeçalho da tabela do print
          color: 'white',
          padding: '12px 16px',
          fontSize: 12,
          fontWeight: 700,
          position: 'sticky',
          top: 0,
          zIndex: 10
        }}>
          <div>Indústria e Comércio (DRE)</div>
          <div style={{ textAlign: 'right' }}>Planejado Acumulado</div>
          <div style={{ textAlign: 'right' }}>Realizado Acumulado</div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
            <div style={{ background: '#374151', borderRadius: 20, display: 'flex', padding: 2 }}>
              <button 
                onClick={() => setVisao('Previsto')}
                style={{ 
                  background: visao === 'Previsto' ? 'white' : 'transparent',
                  color: visao === 'Previsto' ? '#111827' : 'white',
                  border: 'none', borderRadius: 18, padding: '4px 12px', fontSize: 11, fontWeight: 700, cursor: 'pointer'
                }}>Previsto</button>
              <button 
                onClick={() => setVisao('Realizado')}
                style={{ 
                  background: visao === 'Realizado' ? 'white' : 'transparent',
                  color: visao === 'Realizado' ? '#111827' : 'white',
                  border: 'none', borderRadius: 18, padding: '4px 12px', fontSize: 11, fontWeight: 700, cursor: 'pointer'
                }}>Realizado</button>
            </div>
          </div>
        </div>

        <div style={{ paddingBottom: 32 }}>
          {loading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}><Loader2 className="spin" /></div>
          ) : (
            dre.map((item) => (
              <TableRow key={item.id} item={item} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}
