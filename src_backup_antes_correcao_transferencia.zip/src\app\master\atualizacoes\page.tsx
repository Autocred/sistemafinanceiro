'use client';
import React, { useState } from 'react';
import { 
  RefreshCw, CheckCircle2, AlertCircle, Clock, 
  Server, Shield, Zap, ChevronRight, GitCommit 
} from 'lucide-react';

export default function AtualizacoesPage() {
  const [isChecking, setIsChecking] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const handleCheckUpdates = () => {
    setIsChecking(true);
    setTimeout(() => {
      setIsChecking(false);
      alert('O sistema já está na versão mais recente!');
    }, 2000);
  };

  const handleSyncTenants = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      alert('Sincronização forçada enviada para todos os clientes ativos.');
    }, 2500);
  };

  const updates = [
    {
      version: 'v2.4.0',
      date: 'Hoje, 10:30',
      type: 'feature',
      title: 'Novo Painel Master SaaS',
      description: 'Implementação completa da nova arquitetura isolada para gestão de licenças e faturamento dos tenants.',
      icon: <Zap className="w-4 h-4 text-emerald-500" />
    },
    {
      version: 'v2.3.5',
      date: '02 Ago 2026',
      type: 'security',
      title: 'Patch de Segurança Crítico',
      description: 'Atualização nas políticas de CORS e isolamento de banco de dados entre clientes.',
      icon: <Shield className="w-4 h-4 text-red-500" />
    },
    {
      version: 'v2.3.4',
      date: '28 Jul 2026',
      type: 'bugfix',
      title: 'Correção de Faturas Asaas',
      description: 'Resolvido bug onde faturas vencidas não enviavam notificação corretamente pelo webhook.',
      icon: <AlertCircle className="w-4 h-4 text-amber-500" />
    },
    {
      version: 'v2.3.0',
      date: '15 Jul 2026',
      type: 'feature',
      title: 'Módulo de Conciliação Bancária',
      description: 'Adicionada importação de arquivos OFX no módulo financeiro dos clientes.',
      icon: <Zap className="w-4 h-4 text-emerald-500" />
    }
  ];

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">Atualizações do Sistema</h1>
          <p className="text-[var(--text-secondary)] mt-1">Gerencie a versão do ERP Master e o rollout para os clientes.</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button 
            onClick={handleSyncTenants}
            disabled={isSyncing}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--bg-tertiary)] hover:bg-[var(--bg-tertiary-hover)] text-[var(--text-primary)] rounded-lg transition-colors border border-[var(--border)] font-medium disabled:opacity-50"
          >
            <Server className={`w-4 h-4 ${isSyncing ? 'animate-pulse' : ''}`} />
            {isSyncing ? 'Sincronizando...' : 'Sincronizar Clientes'}
          </button>
          <button 
            onClick={handleCheckUpdates}
            disabled={isChecking}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors font-medium shadow-lg shadow-indigo-500/30 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
            {isChecking ? 'Verificando...' : 'Buscar Atualizações'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* COLUNA ESQUERDA - STATUS */}
        <div className="space-y-6">
          <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] relative overflow-hidden">
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <CheckCircle2 className="w-32 h-32 text-emerald-500" />
            </div>
            
            <div className="relative z-10">
              <div className="flex items-center gap-2 mb-2">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                </span>
                <span className="text-sm font-semibold text-emerald-500 uppercase tracking-wider">Sistema Atualizado</span>
              </div>
              
              <h2 className="text-4xl font-black text-[var(--text-primary)] mb-1">v2.4.0</h2>
              <p className="text-[var(--text-secondary)] text-sm mb-6">Última verificação: Há 5 minutos</p>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                  <span className="text-sm text-[var(--text-secondary)]">Branch Ativa</span>
                  <span className="text-sm font-mono text-[var(--text-primary)] bg-[var(--bg-tertiary)] px-2 py-1 rounded">main</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-[var(--border)]">
                  <span className="text-sm text-[var(--text-secondary)]">Último Commit</span>
                  <span className="text-sm font-mono text-indigo-400 flex items-center gap-1">
                    <GitCommit className="w-3 h-3" /> 8f92a1c
                  </span>
                </div>
                <div className="flex justify-between items-center py-2">
                  <span className="text-sm text-[var(--text-secondary)]">Rollout Automático</span>
                  <span className="text-sm font-medium text-emerald-500">Ativado</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] bg-gradient-to-br from-[var(--bg-card)] to-indigo-500/5">
            <h3 className="text-sm font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-indigo-500" />
              Próxima Release (v2.5.0)
            </h3>
            <ul className="space-y-3 text-sm text-[var(--text-secondary)]">
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5"></div>
                Integração com PIX automático via Mercado Pago
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5"></div>
                Módulo de Relatórios Avançados (DRE)
              </li>
              <li className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 mt-1.5"></div>
                Novo App Mobile PWA
              </li>
            </ul>
            <div className="mt-4 pt-4 border-t border-[var(--border)]">
              <div className="flex justify-between items-center text-xs">
                <span className="text-[var(--text-muted)]">Progresso da Release</span>
                <span className="text-indigo-500 font-bold">65%</span>
              </div>
              <div className="w-full h-1.5 bg-[var(--bg-tertiary)] rounded-full mt-2 overflow-hidden">
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: '65%' }}></div>
              </div>
            </div>
          </div>
        </div>

        {/* COLUNA DIREITA - TIMELINE */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-2xl border border-[var(--border)]">
          <h2 className="text-lg font-bold text-[var(--text-primary)] mb-6">Histórico de Atualizações (Changelog)</h2>
          
          <div className="space-y-8 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-[var(--border)] before:via-[var(--border)] before:to-transparent">
            {updates.map((update, index) => (
              <div key={index} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                
                <div className="flex items-center justify-center w-10 h-10 rounded-full border-4 border-[var(--bg-card)] bg-[var(--bg-tertiary)] text-[var(--text-secondary)] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 relative z-10 transition-colors group-hover:bg-[var(--bg-secondary)]">
                  {update.icon}
                </div>
                
                <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-xl border border-[var(--border)] bg-[var(--bg-card)] shadow-sm transition-all hover:shadow-md hover:border-indigo-500/30">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[var(--text-primary)]">{update.version}</span>
                      <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        update.type === 'feature' ? 'bg-emerald-500/10 text-emerald-500' : 
                        update.type === 'security' ? 'bg-red-500/10 text-red-500' : 
                        'bg-amber-500/10 text-amber-500'
                      }`}>
                        {update.type}
                      </span>
                    </div>
                    <span className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {update.date}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-[var(--text-primary)] mb-2">{update.title}</h4>
                  <p className="text-xs text-[var(--text-secondary)] leading-relaxed">
                    {update.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
          
        </div>

      </div>
    </div>
  );
}
