'use client';

import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  User as FirebaseUser
} from 'firebase/auth';
import { getDb, getFirebaseApp } from './firebase';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

export interface AppUser {
  uid: string;
  nome: string;
  email: string;
  telefone?: string;
  empresa?: string;
  cpf?: string;
  avatar?: string;
  ativo?: boolean;
  status: 'pendente' | 'aprovado' | 'recusado' | 'desativado';
  role: 'admin' | 'manager' | 'financeiro' | 'user';
  createdAt: string;
  updatedAt?: string;
  lastLogin?: string;
  tenantId?: string;
  permissoes?: Record<string, boolean>;
}

export function getFirebaseAuth() {
  const app = getFirebaseApp();
  return getAuth(app);
}

export async function getUserProfile(uid: string): Promise<AppUser | null> {
  if (typeof window === 'undefined') return null;
  try {
    const docSnap = await getDoc(doc(getDb(), 'users', uid));
    if (docSnap.exists()) {
      return docSnap.data() as AppUser;
    }
  } catch (error) {
    console.error("Error fetching user profile", error);
  }
  return null;
}

export function subscribeAuth(callback: (user: FirebaseUser | null, profile: AppUser | null) => void) {
  if (typeof window === 'undefined') return () => {};
  const auth = getFirebaseAuth();
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      const profile = await getUserProfile(user.uid);
      callback(user, profile);
    } else {
      callback(null, null);
    }
  });
}

export async function resetarSenha(email: string): Promise<void> {
  const auth = getFirebaseAuth();
  return sendPasswordResetEmail(auth, email);
}

export async function logout() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('master_bypass');
  }
  const auth = getFirebaseAuth();
  await signOut(auth);
}
