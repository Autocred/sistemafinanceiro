'use client';

import React, { useState, useEffect, use } from 'react';
import { getDb } from '@/lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import LicencaBloqueada from '@/components/LicencaBloqueada';

export default function AcessoClientePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const [estado, setEstado] = useState<'loading' | 'redirecionando' | 'bloqueada' | 'vencida' | 'nao_encontrada'>('loading');
  const [nomeEmpresa, setNomeEmpresa] = useState<string>('');

  useEffect(() => {
    async function verificarLicenca() {
      try {
        const db = getDb();
        let docData: any = null;
        const { doc, getDoc } = await import('firebase/firestore');
        const directSnap = await getDoc(doc(db, 'admin_master_licencas', slug));
        if (directSnap.exists()) {
          docData = directSnap.data();
        } else {
          const licencasRef = collection(db, 'admin_master_licencas');
          const q = query(licencasRef, where('dominio', '==', slug));
          const snap = await getDocs(q);
          if (!snap.empty) {
            docData = snap.docs[0].data();
          }
        }

        if (!docData) {
          setEstado('nao_encontrada');
          return;
        }
        const nomeFantasia = docData.nomeFantasia || 'Empresa';
        setNomeEmpresa(nomeFantasia);

        const status = String(docData.status || '').toLowerCase();

        // Verificar se a licença está suspensa
        if (status === 'suspensa') {
          setEstado('bloqueada');
          return;
        }

        // Verificar se a licença está inadimplente
        if (status === 'inadimplente') {
          setEstado('vencida');
          return;
        }

        // Verificar se a data de vencimento expirou
        if (docData.dataVencimento) {
          let dataVenc: Date;
          if (typeof docData.dataVencimento.toDate === 'function') {
            dataVenc = docData.dataVencimento.toDate();
          } else {
            dataVenc = new Date(docData.dataVencimento);
          }
          
          if (dataVenc < new Date()) {
            setEstado('vencida');
            return;
          }
        }

        // Se chegou aqui, a licença está ativa — redirecionar
        if (status === 'ativa' || status === 'teste') {
          setEstado('redirecionando');
          // Pequeno delay para UX suave
          setTimeout(() => {
            window.location.href = `${window.location.origin}/?tenant=${slug}`;
          }, 800);
        } else {
          // Status desconhecido — tratar como bloqueada
          setEstado('bloqueada');
        }

      } catch (error) {
        console.error('[ACESSO] Erro ao verificar licença:', error);
        setEstado('nao_encontrada');
      }
    }

    if (slug) {
      verificarLicenca();
    }
  }, [slug]);

  // ─── Loading State ─────────────────────────────────────────────────
  if (estado === 'loading') {
    return (
      <div
        className="flex min-h-screen w-full items-center justify-center"
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #334155 100%)',
        }}
      >
        <div className="text-center space-y-6 animate-in fade-in duration-500">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <div>
            <h2 className="text-xl font-bold text-white mb-2">Verificando licença...</h2>
            <p className="text-slate-400 text-sm font-medium">
              Validando seu acesso ao sistema
            </p>
          </div>
        </div>
      </div>
    );
  }

  // ─── Redirecionando ────────────────────────────────────────────────
  if (estado === 'redirecionando') {
    return (
      <div
        className="flex min-h-screen w-full items-center justify-center"
        style={{
          background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #334155 100%)',
        }}
      >
        <div className="text-center space-y-6 animate-in fade-in duration-500">
          <div className="w-20 h-20 bg-emerald-500/10 border-2 border-emerald-500/30 rounded-full flex items-center justify-center mx-auto">
            <svg className="w-10 h-10 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <div>
            <h2 className="text-xl font-bold text-white mb-2">Licença válida!</h2>
            <p className="text-slate-400 text-sm font-medium">
              Redirecionando para o painel de <span className="text-emerald-400 font-semibold">{nomeEmpresa}</span>...
            </p>
          </div>
          <div className="w-48 h-1 bg-slate-700 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-emerald-500 rounded-full animate-pulse" style={{ width: '100%', animationDuration: '1s' }} />
          </div>
        </div>
      </div>
    );
  }

  // ─── Licença Suspensa ──────────────────────────────────────────────
  if (estado === 'bloqueada') {
    return <LicencaBloqueada motivo="suspensa" nomeEmpresa={nomeEmpresa} />;
  }

  // ─── Licença Vencida ───────────────────────────────────────────────
  if (estado === 'vencida') {
    return <LicencaBloqueada motivo="vencida" nomeEmpresa={nomeEmpresa} />;
  }

  // ─── Não Encontrada ────────────────────────────────────────────────
  return <LicencaBloqueada motivo="nao_encontrada" />;
}
