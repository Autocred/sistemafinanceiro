'use client';
import React from 'react';
import { Settings, Sliders, Palette, Link as LinkIcon, Database } from 'lucide-react';

export default function ConfiguracoesPage() {
  return (
    <div className="space-y-6 animate-in fade-in duration-700 min-w-0 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-[var(--text-primary)]">Configurações do Master</h1>
        <p className="text-[var(--text-secondary)] mt-1">Ajustes globais do sistema White-Label e integrações.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* White Label */}
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] space-y-4">
          <div className="flex items-center gap-3 mb-4 border-b border-[var(--border)] pb-4">
            <Palette className="w-5 h-5 text-indigo-500" />
            <h2 className="text-lg font-bold text-[var(--text-primary)]">Marca & White Label</h2>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-[var(--text-secondary)] mb-1">Nome do Sistema Principal</label>
            <input type="text" defaultValue="Sistema Financeiro ERP Pro" className="w-full bg-[var(--bg-tertiary)] border border-[var(--border)] rounded-lg p-2.5 text-[var(--text-primary)]" />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-[var(--text-secondary)] mb-1">Domínio Raiz</label>
            <input type="text" defaultValue="seudominio.com.br" className="w-full bg-[var(--bg-tertiary)] border border-[var(--border)] rounded-lg p-2.5 text-[var(--text-primary)]" />
          </div>
          
          <button className="w-full py-2 bg-[var(--bg-secondary)] border border-[var(--border)] text-[var(--text-primary)] font-semibold rounded-lg mt-2 hover:bg-[var(--border)] transition-colors">
            Salvar Marca
          </button>
        </div>

        {/* Integrações */}
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] space-y-4">
          <div className="flex items-center gap-3 mb-4 border-b border-[var(--border)] pb-4">
            <LinkIcon className="w-5 h-5 text-emerald-500" />
            <h2 className="text-lg font-bold text-[var(--text-primary)]">Integrações Globais</h2>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-[var(--text-secondary)] mb-1">Gateway de Pagamento (Asaas API Key)</label>
            <input type="password" defaultValue="************************" className="w-full bg-[var(--bg-tertiary)] border border-[var(--border)] rounded-lg p-2.5 text-[var(--text-primary)]" />
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-[var(--text-secondary)] mb-1">Servidor SMTP (Envio de E-mails)</label>
            <input type="text" defaultValue="smtp.sendgrid.net" className="w-full bg-[var(--bg-tertiary)] border border-[var(--border)] rounded-lg p-2.5 text-[var(--text-primary)]" />
          </div>

          <button className="w-full py-2 bg-[var(--bg-secondary)] border border-[var(--border)] text-[var(--text-primary)] font-semibold rounded-lg mt-2 hover:bg-[var(--border)] transition-colors">
            Atualizar Integrações
          </button>
        </div>

      </div>
    </div>
  );
}
