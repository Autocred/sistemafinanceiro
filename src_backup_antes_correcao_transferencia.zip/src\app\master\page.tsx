'use client';
import React, { useState, useEffect } from 'react';
import { 
  Building2, Users, Database, Server, CreditCard, 
  TrendingUp, Activity, ShieldCheck, Cpu, HardDrive, 
  Wallet, Rocket, ArrowUpRight, ArrowDownRight, MoreHorizontal
} from 'lucide-react';
import { getDb } from '@/lib/firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import { formatarMoeda } from '@/lib/storage';

export default function MasterDashboard() {
  
  const [metricas, setMetricas] = useState({
    licencasAtivas: 0,
    clientesOnline: 0, // mock for now
    mrr: 0,
    faturado30d: 0,
    licencasVencendo: 0,
    inadimplentes: 0
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const db = getDb();
    
    // Realtime listeners
    const unsubLicencas = onSnapshot(collection(db, 'admin_master_licencas'), (snap) => {
      let ativas = 0;
      let vencendo = 0;
      let inadimplentes = 0;
      
      const hoje = new Date();
      const em7Dias = new Date();
      em7Dias.setDate(em7Dias.getDate() + 7);

      snap.forEach(doc => {
        const l = doc.data();
        if (l.status === 'ativa') ativas++;
        if (l.status === 'inadimplente') inadimplentes++;
        
        if (l.dataVencimento) {
          const v = l.dataVencimento.toDate();
          if (v > hoje && v <= em7Dias) {
            vencendo++;
          }
        }
      });
      
      setMetricas(prev => ({
        ...prev, 
        licencasAtivas: ativas, 
        licencasVencendo: vencendo,
        inadimplentes
      }));
    });

    const unsubFaturas = onSnapshot(collection(db, 'admin_master_faturas'), (snap) => {
      let faturado = 0;
      let mrrPrevisto = 0;
      
      const mesAtual = new Date().toISOString().substring(0,7);
      
      snap.forEach(doc => {
        const f = doc.data();
        // Faturado no mes (pagos)
        if (f.status === 'pago' && f.dataVencimento?.startsWith(mesAtual)) {
          faturado += f.valor;
        }
        // MRR Previsto (todas do mes ativo)
        if (f.status !== 'cancelada' && f.dataVencimento?.startsWith(mesAtual)) {
          mrrPrevisto += f.valor;
        }
      });
      
      setMetricas(prev => ({
        ...prev,
        mrr: mrrPrevisto,
        faturado30d: faturado
      }));
      setLoading(false);
    });

    return () => {
      unsubLicencas();
      unsubFaturas();
    };
  }, []);

  const infrastructure = [
    { name: 'Uso de CPU', percent: 12, color: 'bg-blue-500', icone: <Cpu className="w-4 h-4 text-blue-600" /> },
    { name: 'Memória RAM', percent: 28, color: 'bg-emerald-500', icone: <Activity className="w-4 h-4 text-emerald-600" /> },
    { name: 'Espaço em Disco', percent: 15, color: 'bg-orange-500', icone: <HardDrive className="w-4 h-4 text-orange-600" /> },
    { name: 'Banco de Dados', percent: 5, color: 'bg-purple-500', icone: <Database className="w-4 h-4 text-purple-600" /> },
  ];

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 bg-gray-50 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-gray-900 flex items-center gap-3">
            Dashboard Comercial
          </h1>
          <p className="text-gray-500 mt-1">Visão geral e indicadores de desempenho (KPIs) das suas vendas SaaS em tempo real.</p>
        </div>
        <div className="flex gap-2">
          <select className="bg-white border border-gray-300 text-gray-700 text-sm font-semibold rounded-lg focus:ring-blue-500 focus:border-blue-500 block px-3 py-2 outline-none shadow-sm">
            <option>Mês Atual</option>
            <option>Últimos 30 dias</option>
            <option>Este Ano</option>
          </select>
        </div>
      </div>

      {/* ALERTAS INTELIGENTES */}
      {(metricas.licencasVencendo > 0 || metricas.inadimplentes > 0) && (
        <div className="flex flex-col gap-3">
          {metricas.licencasVencendo > 0 && (
            <div className="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-xl shadow-sm flex items-center gap-3">
              <span className="text-xl">🔔</span>
              <span className="font-semibold text-sm">{metricas.licencasVencendo} licença(s) vencem nos próximos 7 dias. Acompanhe as renovações.</span>
            </div>
          )}
          {metricas.inadimplentes > 0 && (
            <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-xl shadow-sm flex items-center gap-3">
              <span className="text-xl">🚨</span>
              <span className="font-semibold text-sm">{metricas.inadimplentes} cliente(s) constam como inadimplentes. Inicie a régua de cobrança.</span>
            </div>
          )}
        </div>
      )}

      {/* KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-1">Receita MRR</p>
              <h3 className="text-3xl font-black text-gray-900">{formatarMoeda(metricas.mrr)}</h3>
            </div>
            <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-sm">
            <span className="text-emerald-600 font-bold flex items-center bg-emerald-50 px-1.5 py-0.5 rounded"><ArrowUpRight className="w-3 h-3"/> 12.4%</span>
            <span className="text-gray-400 font-medium">vs. mês passado</span>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-1">Recebido</p>
              <h3 className="text-3xl font-black text-gray-900">{formatarMoeda(metricas.faturado30d)}</h3>
            </div>
            <div className="w-10 h-10 rounded-full bg-emerald-50 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-emerald-600" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-sm">
            <span className="text-gray-400 font-medium">Faturas pagas no mês</span>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-1">Licenças Ativas</p>
              <h3 className="text-3xl font-black text-gray-900">{metricas.licencasAtivas}</h3>
            </div>
            <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center">
              <Building2 className="w-5 h-5 text-orange-600" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-sm">
            <span className="text-emerald-600 font-bold flex items-center bg-emerald-50 px-1.5 py-0.5 rounded"><ArrowUpRight className="w-3 h-3"/> 2 novos</span>
            <span className="text-gray-400 font-medium">esta semana</span>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-1">Inadimplência</p>
              <h3 className="text-3xl font-black text-gray-900">{metricas.inadimplentes}</h3>
            </div>
            <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center">
              <Activity className="w-5 h-5 text-red-600" />
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-sm">
            <span className="text-gray-400 font-medium">Clientes com faturas atrasadas</span>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* GRÁFICO PLACEHOLDER */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-gray-200 p-6 flex flex-col min-h-[400px] shadow-sm relative overflow-hidden">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-gray-900 text-lg">Evolução de Receita</h3>
            <button className="text-gray-400 hover:text-gray-600"><MoreHorizontal className="w-5 h-5"/></button>
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center text-center">
            <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mb-4 border border-blue-100">
              <Rocket className="w-10 h-10" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">Pronto para decolar!</h2>
            <p className="text-gray-500 max-w-sm mx-auto text-sm">
              Os gráficos de receita e conversões aparecerão aqui assim que as primeiras assinaturas completarem ciclos mensais.
            </p>
          </div>
        </div>

        {/* SAÚDE DO SISTEMA */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 flex flex-col shadow-sm">
          <div className="flex items-center gap-3 mb-8 pb-4 border-b border-gray-100">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg border border-blue-100">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900">Saúde da Infra</h2>
              <p className="text-xs text-gray-500 font-medium">Uso atual de recursos</p>
            </div>
          </div>
          
          <div className="space-y-6 flex-1">
            {infrastructure.map((item, i) => (
              <div key={i} className="group">
                <div className="flex justify-between text-sm font-semibold mb-2">
                  <span className="text-gray-700 flex items-center gap-2">
                    <div className="p-1.5 bg-gray-50 border border-gray-200 rounded-md">
                      {item.icone}
                    </div>
                    {item.name}
                  </span>
                  <span className="text-gray-900 font-bold">{item.percent}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div 
                    className={`h-full rounded-full ${item.color}`} 
                    style={{ width: `${item.percent}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 pt-4 border-t border-gray-100">
            <div className="flex items-center gap-2 px-3 py-2 bg-emerald-50 rounded-lg border border-emerald-100">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span className="text-xs font-bold text-emerald-700">Todos os serviços online</span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
