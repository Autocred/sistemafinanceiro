import { NextResponse } from 'next/server';
import { adminDb } from '@/lib/firebase-admin';

export async function GET() {
  try {
    if (!adminDb) return NextResponse.json({ error: 'No admin db' }, { status: 500 });
    
    // Encontrar transacao de 37.35
    const transacoesRef = adminDb.collection('transacoes');
    const snapshot = await transacoesRef.where('valor', '==', 37.35).get();
    
    if (snapshot.empty) {
      return NextResponse.json({ message: 'Nenhuma transacao de 37.35 encontrada' });
    }

    const logs = [];

    for (const doc of snapshot.docs) {
      const t = doc.data();
      logs.push(`Encontrada transacao: ${doc.id}`);
      
      const cartaoId = t.cartaoId || 'snh7128qndz'; // Fallback for the likely card ID if missing
      
      const cartaoSnap = await adminDb.collection('cartoes').doc(cartaoId).get();
      let cartao = { nome: 'Cartão', cor: '#3b82f6', dataVencimento: 4 };
      if (cartaoSnap.exists) {
        cartao = cartaoSnap.data() as any;
      }
      
      const mesRef = '2026-09';
      
      const faturasSnap = await adminDb.collection('faturas')
        .where('cartaoId', '==', cartaoId)
        .where('mesReferencia', '==', mesRef)
        .get();
        
      let faturaRef;
      let faturaData;
      
      if (faturasSnap.empty) {
         logs.push(`Criando fatura ${mesRef} para o cartao ${cartaoId}`);
         faturaRef = adminDb.collection('faturas').doc();
         faturaData = {
           id: faturaRef.id,
           cartaoId: cartaoId,
           cartaoNome: cartao.nome,
           cartaoCor: cartao.cor || '#3b82f6',
           mesReferencia: mesRef,
           dataFechamento: `2026-09-04`,
           dataVencimento: `2026-09-04`,
           valorTotal: t.valor,
           status: 'aberta',
           transacaoIds: [doc.id],
           pagamentos: []
         };
         await faturaRef.set(faturaData);
      } else {
         faturaRef = faturasSnap.docs[0].ref;
         faturaData = faturasSnap.docs[0].data();
         
         if (!faturaData.transacaoIds.includes(doc.id)) {
           const newTotal = faturaData.valorTotal + t.valor;
           const newIds = [...faturaData.transacaoIds, doc.id];
           await faturaRef.update({ valorTotal: newTotal, transacaoIds: newIds });
           logs.push(`Adicionado à fatura existente ${faturaRef.id}. Total alterado para ${newTotal}`);
         } else {
           logs.push(`Fatura ${faturaRef.id} ja contem a transacao`);
         }
      }
      
      // Update transaction
      await doc.ref.update({ 
        faturaId: faturaRef.id,
        formaPagamento: 'cartao_credito',
        cartaoId: cartaoId
      });
      logs.push(`Transacao atualizada com faturaId ${faturaRef.id}`);
    }
    
    return NextResponse.json({ logs });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
