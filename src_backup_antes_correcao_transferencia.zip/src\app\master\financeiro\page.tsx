'use client';
import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { 
  CreditCard, DollarSign, ArrowDownToLine, ArrowUpRight, 
  Search, ShieldAlert, CheckCircle2, History, PlusCircle, MoreVertical, AlertTriangle, Globe, Receipt, Building2, Calendar, Filter
} from 'lucide-react';
import { getDb } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { atualizarStatusFaturaSaaS } from '@/lib/saas/billingManager';
import { formatarMoeda } from '@/lib/storage';

export default function FinanceiroMaster() {
  const router = useRouter();
  const [faturas, setFaturas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<string>('todas');

  useEffect(() => {
    const db = getDb();
    const q = query(collection(db, 'admin_master_faturas'), orderBy('dataVencimento', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snap) => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setFaturas(lista);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleStatusChange = async (id: string, novoStatus: 'pago' | 'pendente' | 'atrasado' | 'cancelada') => {
    try {
      await atualizarStatusFaturaSaaS(id, novoStatus, novoStatus === 'pago' ? new Date().toISOString().split('T')[0] : undefined);
    } catch (e) {
      console.error(e);
    }
  };

  const faturasFiltradas = faturas.filter(f => {
    const matchBusca = 
      f.clienteNome?.toLowerCase().includes(busca.toLowerCase()) || 
      f.dominio?.toLowerCase().includes(busca.toLowerCase());
      
    if (filtroStatus === 'todas') return matchBusca;
    return matchBusca && f.status === filtroStatus;
  });

  const previstoAgosto = faturas.filter(f => f.dataVencimento?.startsWith(new Date().toISOString().substring(0,7))).reduce((a, b) => a + b.valor, 0);
  const recebidoAgosto = faturas.filter(f => f.status === 'pago' && f.dataVencimento?.startsWith(new Date().toISOString().substring(0,7))).reduce((a, b) => a + b.valor, 0);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pago': return <span className="px-2.5 py-1 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 w-max"><CheckCircle2 className="w-3.5 h-3.5"/> Pago</span>;
      case 'pendente': return <span className="px-2.5 py-1 bg-amber-50 text-amber-600 border border-amber-200 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 w-max"><History className="w-3.5 h-3.5"/> Pendente</span>;
      case 'atrasado': return <span className="px-2.5 py-1 bg-red-50 text-red-600 border border-red-200 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 w-max"><AlertTriangle className="w-3.5 h-3.5"/> Atrasado</span>;
      case 'cancelada': return <span className="px-2.5 py-1 bg-gray-100 text-gray-600 border border-gray-200 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 w-max"><ShieldAlert className="w-3.5 h-3.5"/> Cancelada</span>;
      default: return null;
    }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 bg-gray-50 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-gray-900 flex items-center gap-3">
            <DollarSign className="w-8 h-8 text-blue-600" />
            Financeiro SaaS
          </h1>
          <p className="text-gray-500 mt-1">Gestão de faturamento, cobranças e inadimplência.</p>
        </div>
        <button 
          onClick={() => router.push('/master/financeiro/nova-venda')}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all shadow-md transform hover:-translate-y-0.5"
        >
          <PlusCircle className="w-5 h-5" />
          Nova Venda / Cobrança
        </button>
      </div>

      {/* KPI CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm group hover:shadow-md transition-all">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-50 border border-blue-100 rounded-xl flex items-center justify-center text-blue-600">
              <DollarSign className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Total Faturado</p>
              <p className="text-xs text-gray-400">Mês Atual</p>
            </div>
          </div>
          <div className="text-3xl font-black text-gray-900">{formatarMoeda(previstoAgosto)}</div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm group hover:shadow-md transition-all">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-600">
              <ArrowDownToLine className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Total Recebido</p>
              <p className="text-xs text-gray-400">Mês Atual</p>
            </div>
          </div>
          <div className="text-3xl font-black text-gray-900">{formatarMoeda(recebidoAgosto)}</div>
        </div>

        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm group hover:shadow-md transition-all">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-red-50 border border-red-100 rounded-xl flex items-center justify-center text-red-600">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Inadimplência</p>
              <p className="text-xs text-gray-400">Geral</p>
            </div>
          </div>
          <div className="text-3xl font-black text-gray-900">
            {faturas.filter(f => f.status === 'atrasado').length} <span className="text-sm text-gray-500 font-medium">faturas</span>
          </div>
        </div>
      </div>

      {/* FILTROS E BUSCA */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 flex flex-col md:flex-row gap-4 items-center justify-between shadow-sm">
        <div className="relative w-full md:w-[400px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Buscar fatura por cliente ou domínio..." 
            value={busca}
            onChange={e => setBusca(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 text-gray-900 placeholder-gray-400 rounded-xl pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-sm"
          />
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 text-sm text-gray-500 font-semibold bg-gray-50 px-3 py-2.5 border border-gray-200 rounded-xl">
            <Filter className="w-4 h-4" />
            Filtrar por Status:
            <select 
              value={filtroStatus}
              onChange={e => setFiltroStatus(e.target.value)}
              className="bg-transparent border-none outline-none font-bold text-gray-900 cursor-pointer"
            >
              <option value="todas">Todas</option>
              <option value="pago">Pagas</option>
              <option value="pendente">Pendentes</option>
              <option value="atrasado">Atrasadas</option>
              <option value="cancelada">Canceladas</option>
            </select>
          </div>
        </div>
      </div>

      {/* DATAGRID / TABLE */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm flex flex-col min-h-[400px]">
        <div className="overflow-x-auto flex-1 custom-scrollbar">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600">
              <tr>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Cliente / Tenant</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Vencimento</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Valor Total</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Status</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center justify-center gap-3">
                      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                      <span className="text-gray-500 font-medium">Carregando faturas...</span>
                    </div>
                  </td>
                </tr>
              ) : faturasFiltradas.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center">
                    <Receipt className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-medium text-lg">Nenhuma fatura encontrada.</p>
                  </td>
                </tr>
              ) : (
                faturasFiltradas.map((fatura) => (
                  <tr key={fatura.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center border border-gray-200 shrink-0">
                          <Building2 className="w-5 h-5 text-gray-500" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors cursor-pointer" onClick={() => router.push(`/master/licencas/${fatura.tenantId}`)}>{fatura.clienteNome}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-xs text-blue-600 font-semibold bg-blue-50 px-2 py-0.5 rounded border border-blue-100">{fatura.dominio}</span>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-gray-700 font-medium">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {fatura.dataVencimento ? new Date(fatura.dataVencimento + 'T12:00:00').toLocaleDateString('pt-BR') : '-'}
                      </div>
                      <p className="text-xs text-gray-500 mt-1">{fatura.descricao}</p>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-lg font-black text-gray-900">{formatarMoeda(fatura.valor)}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(fatura.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      {fatura.status === 'pendente' || fatura.status === 'atrasado' ? (
                        <div className="flex justify-end gap-2">
                          <button 
                            onClick={() => handleStatusChange(fatura.id, 'pago')}
                            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold py-1.5 px-3 rounded-lg text-sm transition-colors border border-emerald-200"
                          >
                            Baixar Pagamento
                          </button>
                        </div>
                      ) : fatura.status === 'pago' ? (
                        <span className="text-sm font-medium text-gray-400">Fechada</span>
                      ) : null}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
