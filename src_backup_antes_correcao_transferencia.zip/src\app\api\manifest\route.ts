import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const tenant = searchParams.get('tenant');

  if (tenant === 'autocred-promotora-de-credito' || tenant?.includes('autocred')) {
    return NextResponse.json({
      name: "Autocred Promotora de Crédito",
      short_name: "Autocred",
      description: "Sistema Financeiro Autocred Promotora de Crédito",
      id: "/?tenant=autocred-promotora-de-credito",
      start_url: "/?tenant=autocred-promotora-de-credito",
      display: "standalone",
      background_color: "#0f172a",
      theme_color: "#0284c7",
      orientation: "portrait",
      icons: [
        {
          src: "/autocred-icon.png?v=12",
          sizes: "192x192",
          type: "image/png",
          purpose: "any maskable"
        },
        {
          src: "/autocred-icon.png?v=12",
          sizes: "512x512",
          type: "image/png",
          purpose: "any maskable"
        }
      ],
      categories: ["finance", "productivity", "utilities"],
      lang: "pt-BR"
    });
  }

  // Default FinPessoal Master Manifest
  return NextResponse.json({
    name: "FinPessoal Master ERP",
    short_name: "FinPessoal",
    description: "Sistema Financeiro Pessoal ERP Pro — Padrão Bancário Premium",
    id: "/finpessoal-master",
    start_url: "/",
    display: "standalone",
    background_color: "#0f0a0a",
    theme_color: "#cc092f",
    orientation: "portrait",
    icons: [
      {
        src: "/icon-192.png?v=12",
        sizes: "192x192",
        type: "image/png",
        purpose: "any maskable"
      },
      {
        src: "/icon-512.png?v=12",
        sizes: "512x512",
        type: "image/png",
        purpose: "any maskable"
      },
      {
        src: "/icon.svg?v=12",
        sizes: "512x512",
        type: "image/svg+xml",
        purpose: "any maskable"
      }
    ],
    categories: ["finance", "productivity", "utilities"],
    lang: "pt-BR"
  });
}
