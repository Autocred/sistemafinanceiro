import { NextResponse } from 'next/server';
import { adminDb } from '@/lib/firebase-admin';
import { getAuth } from 'firebase-admin/auth';

export async function POST(req: Request) {
  try {
    const { uid, newPassword, tenantId } = await req.json();

    if (!uid || !newPassword) {
      return NextResponse.json(
        { error: 'Campos obrigatórios: uid, newPassword' }, 
        { status: 400 }
      );
    }

    if (newPassword.length < 6) {
      return NextResponse.json(
        { error: 'A senha deve ter no mínimo 6 caracteres.' }, 
        { status: 400 }
      );
    }

    // 1. Atualizar senha no Firebase Auth via Admin SDK
    const auth = getAuth();
    await auth.updateUser(uid, { password: newPassword });

    // 2. Marcar no Firestore que o usuário precisa trocar a senha no próximo login
    if (adminDb) {
      try {
        await adminDb.collection('users').doc(uid).update({
          requirePasswordChange: true,
          senhaAlteradaPeloMaster: true,
          ultimaAlteracaoSenha: new Date().toISOString(),
        });

        // Se tem tenantId, atualiza também na subcoleção do tenant
        if (tenantId) {
          await adminDb.collection(`tenants/${tenantId}/users`).doc(uid).update({
            requirePasswordChange: true,
            senhaAlteradaPeloMaster: true,
            ultimaAlteracaoSenha: new Date().toISOString(),
          });
        }
      } catch (firestoreError) {
        console.error('[RESET-PASSWORD] Erro ao atualizar Firestore:', firestoreError);
        // Não falhar a operação inteira — a senha já foi trocada no Auth
      }
    }

    return NextResponse.json({ 
      success: true,
      message: 'Senha alterada com sucesso. O usuário será obrigado a trocar a senha no próximo login.'
    });

  } catch (error: any) {
    console.error('[RESET-PASSWORD] Erro:', error);

    // Tratar erros específicos do Firebase Admin
    if (error.code === 'auth/user-not-found') {
      return NextResponse.json(
        { error: 'Usuário não encontrado no Firebase Auth.' }, 
        { status: 404 }
      );
    }
    if (error.code === 'auth/invalid-password') {
      return NextResponse.json(
        { error: 'A senha fornecida é inválida.' }, 
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: error.message || 'Erro interno ao resetar senha.' }, 
      { status: 500 }
    );
  }
}
