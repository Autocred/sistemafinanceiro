'use client';

import React from 'react';
import { ShieldAlert, ShieldX, SearchX, Phone, Mail, ArrowLeft, Lock } from 'lucide-react';

interface LicencaBloqueadaProps {
  motivo: 'suspensa' | 'vencida' | 'nao_encontrada';
  nomeEmpresa?: string;
}

export default function LicencaBloqueada({ motivo, nomeEmpresa }: LicencaBloqueadaProps) {

  const configs = {
    suspensa: {
      icone: <ShieldX className="w-14 h-14" />,
      titulo: 'Licença Suspensa',
      subtitulo: 'O acesso ao sistema foi temporariamente suspenso pelo administrador.',
      descricao: 'Entre em contato com o suporte para regularizar sua situação e reativar o acesso.',
      corIcone: 'from-red-500 to-rose-600',
      corBorda: 'border-red-200',
      corFundo: 'bg-red-50',
      corTexto: 'text-red-600',
    },
    vencida: {
      icone: <Lock className="w-14 h-14" />,
      titulo: 'Licença Vencida',
      subtitulo: 'Sua licença de acesso expirou e precisa ser renovada.',
      descricao: 'Realize o pagamento da fatura pendente para renovar automaticamente o seu acesso.',
      corIcone: 'from-amber-500 to-orange-600',
      corBorda: 'border-amber-200',
      corFundo: 'bg-amber-50',
      corTexto: 'text-amber-600',
    },
    nao_encontrada: {
      icone: <SearchX className="w-14 h-14" />,
      titulo: 'Licença Não Encontrada',
      subtitulo: 'Nenhuma licença foi localizada para este endereço.',
      descricao: 'Verifique se o link está correto ou entre em contato com o suporte técnico.',
      corIcone: 'from-slate-500 to-gray-600',
      corBorda: 'border-gray-200',
      corFundo: 'bg-gray-50',
      corTexto: 'text-gray-600',
    },
  };

  const cfg = configs[motivo];
  const whatsappNumero = '5549998266304';
  const whatsappMensagem = encodeURIComponent(
    `Olá! Preciso de suporte com minha licença.${nomeEmpresa ? `\nEmpresa: ${nomeEmpresa}` : ''}\nMotivo: ${cfg.titulo}`
  );

  return (
    <div 
      className="flex min-h-screen w-full items-center justify-center p-4"
      style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 40%, #334155 100%)',
      }}
    >
      {/* Decorative Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-red-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/3 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Main Card */}
        <div className="bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/20 overflow-hidden">
          
          {/* Top Gradient Bar */}
          <div className={`h-1.5 bg-gradient-to-r ${cfg.corIcone}`} />

          <div className="p-8 md:p-10 text-center">
            {/* Animated Icon */}
            <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${cfg.corIcone} text-white flex items-center justify-center mx-auto mb-6 shadow-lg animate-pulse`}
              style={{ animationDuration: '3s' }}
            >
              {cfg.icone}
            </div>

            {/* Company Name */}
            {nomeEmpresa && (
              <div className="mb-4">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  {nomeEmpresa}
                </span>
              </div>
            )}

            {/* Title */}
            <h1 className="text-2xl md:text-3xl font-black text-slate-900 mb-3 tracking-tight">
              {cfg.titulo}
            </h1>

            {/* Subtitle */}
            <p className="text-slate-600 font-medium mb-2">
              {cfg.subtitulo}
            </p>

            {/* Description */}
            <p className="text-sm text-slate-500 mb-8 max-w-sm mx-auto leading-relaxed">
              {cfg.descricao}
            </p>

            {/* Alert Box */}
            <div className={`${cfg.corFundo} ${cfg.corBorda} border rounded-2xl p-4 mb-8`}>
              <div className="flex items-center justify-center gap-2">
                <ShieldAlert className={`w-5 h-5 ${cfg.corTexto} flex-shrink-0`} />
                <p className={`text-sm font-bold ${cfg.corTexto}`}>
                  {motivo === 'vencida' 
                    ? 'Regularize seu pagamento para reativar o acesso' 
                    : motivo === 'suspensa'
                    ? 'Seu acesso foi bloqueado temporariamente'
                    : 'Verifique o endereço de acesso com o suporte'}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              {/* WhatsApp Button */}
              <a
                href={`https://wa.me/${whatsappNumero}?text=${whatsappMensagem}`}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-3 py-4 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl transition-all shadow-lg shadow-emerald-600/25 hover:shadow-emerald-600/40 hover:-translate-y-0.5 active:translate-y-0"
              >
                <Phone className="w-5 h-5" />
                Falar com Suporte via WhatsApp
              </a>

              {/* Email Button */}
              <a
                href="mailto:suporte@financeai.com?subject=Suporte - Licença"
                className="w-full flex items-center justify-center gap-3 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-2xl transition-all border border-slate-200"
              >
                <Mail className="w-5 h-5" />
                Contato por E-mail
              </a>

              {/* Back Button */}
              <button
                onClick={() => window.history.back()}
                className="w-full flex items-center justify-center gap-2 py-3 text-slate-500 hover:text-slate-700 font-medium text-sm transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Voltar
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-6">
          <p className="text-slate-500/60 text-xs font-medium">
            FinanceAI © {new Date().getFullYear()} — Todos os direitos reservados
          </p>
        </div>
      </div>
    </div>
  );
}
