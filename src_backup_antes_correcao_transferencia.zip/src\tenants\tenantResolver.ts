import { AUTOCRED_CONFIG } from './autocred/autocredConfig';
import { MASTER_CONFIG } from './master/masterConfig';

export function getTenantConfig(tenantId?: string | null) {
  if (tenantId === 'autocred-promotora-de-credito' || tenantId?.includes('autocred')) {
    return AUTOCRED_CONFIG;
  }
  return MASTER_CONFIG;
}
