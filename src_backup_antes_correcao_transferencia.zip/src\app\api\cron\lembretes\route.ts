import { NextResponse } from 'next/server';
import { getFirebaseApp, getDb } from '@/lib/firebase';
import { collection, query, getDocs, doc, addDoc } from 'firebase/firestore';
import { enviarMensagemWhatsApp } from '@/lib/whatsapp';
import { ConfiguracaoApp, Transacao } from '@/lib/types';

// Opcional: Proteger a rota do CRON (Vercel manda header x-vercel-cron)
// https://vercel.com/docs/cron-jobs/manage-cron-jobs#securing-cron-jobs
const CRON_SECRET = process.env.CRON_SECRET || 'dev_secret_financeai';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('Authorization');
    // Para teste local, ignãora verificação se não passar Authorization
    if (authHeader && authHeader !== `Bearer ${CRON_SECRET}`) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    console.log('[CRON] Iniciando rotina de Lembretes e Automações...');

    const db = getDb();
    const usersSnap = await getDocs(collection(db, 'users'));
    
    let processados = 0;
    let enviosZap = 0;
    
    const hojeData = new Date();
    const hojeStr = hojeData.toISOString().split('T')[0];

    for (const userDoc of usersSnap.docs) {
      const userId = userDoc.id;
      
      // Busca configurações
      const confSnap = await getDocs(collection(db, 'users', userId, 'configuracoes'));
      let cfg: ConfiguracaoApp | null = null;
      if (!confSnap.empty) {
        cfg = confSnap.docs[0].data() as ConfiguracaoApp;
      }
      
      if (!cfg || !cfg.whatsappAtivo || !cfg.whatsappNumeros) continue;
      
      processados++;

      // Busca despesas pendentes
      const transQ = query(collection(db, 'users', userId, 'transacoes'));
      const transSnap = await getDocs(transQ);
      
      const transacoes = transSnap.docs.map(d => ({ id: d.id, ...d.data() } as Transacao));
      
      const despesasPendentes = transacoes.filter(t => 
        t.tipo === 'despesa' && 
        (t.status === 'pendente' || t.status === 'atrasado') &&
        t.formaPagamento !== 'cartao_credito' // faturas trataremos depois
      );
      
      const faturasPendentes = transacoes.filter(t => 
        t.tipo === 'despesa' && 
        t.formaPagamento === 'cartao_credito' // simplificação para este cron
      );
      
      // Contas de Hoje
      const venceHoje = despesasPendentes.filter(t => t.dataVencimento === hojeStr || t.data === hojeStr);
      const atrasadas = despesasPendentes.filter(t => (t.dataVencimento || t.data) < hojeStr);
      
      const proximos = despesasPendentes.filter(t => {
        const d = t.dataVencimento || t.data;
        if (d <= hojeStr) return false;
        const diff = Math.ceil((new Date(d).getTime() - hojeData.getTime()) / (1000 * 3600 * 24));
        return diff <= 7;
      });

      if (venceHoje.length === 0 && atrasadas.length === 0 && proximos.length === 0) {
        continue; // Tudo em dia, não envia nada para não incomodar
      }

      const fmt = (v: number) => `R$ ${v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      
      let texto = `*FinanceAI - Bom dia, ${cfg.nomeUsuario || 'Usuário'}!* ☀️\n\n`;
      texto += `Aqui está o seu resumo financeiro de hoje:\n\n`;
      
      if (venceHoje.length > 0) {
        texto += `🔴 *VENCEM HOJE:*\n`;
        venceHoje.forEach(t => {
          texto += `- ${t.descricao}: ${fmt(t.valor)}\n`;
        });
        texto += `\n`;
      }
      
      if (atrasadas.length > 0) {
        texto += `⚠️ *ATRASADAS:*\n`;
        atrasadas.forEach(t => {
          texto += `- ${t.descricao}: ${fmt(t.valor)} (Venc: ${t.data.split('-').reverse().join('/')})\n`;
        });
        texto += `\n`;
      }
      
      if (proximos.length > 0) {
        texto += `🟡 *PRÓXIMOS 7 DIAS:*\n`;
        proximos.forEach(t => {
          texto += `- ${t.descricao}: ${fmt(t.valor)} (Venc: ${t.data.split('-').reverse().join('/')})\n`;
        });
        texto += `\n`;
      }
      
      texto += `_Lembre-se de acessar o sistema para marcar como pago após a liquidação!_`;

      const numeros = cfg.whatsappNumeros.split(',').map(n => n.trim()).filter(n => n);
      
      for (const numero of numeros) {
        const resultado = await enviarMensagemWhatsApp(numero, texto);
        if (resultado.sucesso) enviosZap++;
        
        // Gera NotificacaoApp não Firebase também (Sinão)
        if (cfg.lembretesSino !== false && (venceHoje.length > 0 || atrasadas.length > 0)) {
          await addDoc(collection(db, 'users', userId, 'notificacoes'), {
            tipo: atrasadas.length > 0 ? 'atraso' : 'vencimento',
            titulo: 'Resumo Diário de Contas',
            mensagem: `Você possui ${venceHoje.length} contas vencendo hoje e ${atrasadas.length} atrasadas.`,
            data: hojeStr,
            hora: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            prioridade: atrasadas.length > 0 ? 'urgente' : 'alta',
            lida: false,
            criadoEm: new Date().toISOString()
          });
        }
      }
    }

    return NextResponse.json({ 
      success: true, 
      message: 'CRON executado com sucesso',
      usuariosProcessados: processados,
      disparosWhatsapp: enviosZap
    });
    
  } catch (error) {
    console.error('[CRON] Erro:', error);
    return NextResponse.json({ error: 'Erro ao executar rotina' }, { status: 500 });
  }
}
