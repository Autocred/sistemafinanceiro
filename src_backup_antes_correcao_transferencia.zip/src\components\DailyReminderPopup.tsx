'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { BellRing, X, Calendar, ArrowRight, CheckCircle2, AlertTriangle, DollarSign } from 'lucide-react';
import { Transacao } from '@/lib/types';
import { getTransacoes, atualizarTransacao, formatarMoeda } from '@/lib/storage';
import { playSound } from '@/lib/audio';

export function DailyReminderPopup({ userId, setActiveTab }: { userId?: string; setActiveTab?: (tab: string) => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [contasVencendo, setContasVencendo] = useState<Transacao[]>([]);
  const [loading, setLoading] = useState(true);

  const checarContasEAlertar = useCallback(async () => {
    try {
      let transacoes: Transacao[] = [];
      try {
        if (!userId) throw new Error('Offline mode');
        transacoes = await getTransacoes();
        localStorage.setItem('cached_transacoes_vencendo', JSON.stringify(transacoes));
      } catch (err) {
        const cached = localStorage.getItem('cached_transacoes_vencendo');
        if (cached) transacoes = JSON.parse(cached);
      }
      if (!transacoes || transacoes.length === 0) return;

      const hojeStr = new Date().toISOString().split('T')[0];

      // Feriados Nacionais Fixos do Brasil
      const FERIADOS_NACIONAIS = [
        '01-01', '04-21', '05-01', '09-07', '10-12', '11-02', '11-15', '12-25'
      ];
      
      const isFeriadoOuFds = (dataStr: string) => {
         const d = new Date(dataStr + 'T12:00:00');
         const day = d.getDay();
         if (day === 0 || day === 6) return true;
         const mesDia = dataStr.substring(5);
         if (FERIADOS_NACIONAIS.includes(mesDia)) return true;
         return false;
      };

      const getDiaUtilAnterior = (dataStr: string) => {
         let date = new Date(dataStr + 'T12:00:00');
         date.setDate(date.getDate() - 1);
         while (isFeriadoOuFds(date.toISOString().split('T')[0])) {
            date.setDate(date.getDate() - 1);
         }
         return date.toISOString().split('T')[0];
      };

      // Filtra despesas ou receitas pendentes vencendo hoje, atrasadas ou antecipadas pelo FDS/Feriado
      const pendentesVencendo = transacoes.filter(t => {
        if (t.status === 'pago') return false;
        const dtVenc = t.dataVencimento || t.data;
        if (!dtVenc) return false;
        
        // Vencendo hoje ou atrasada
        if (dtVenc <= hojeStr) return true;
        
        // Se vence não futuro, mas cai em feriado/FDS e o "dia útil anterior" é hoje
        if (isFeriadoOuFds(dtVenc)) {
           const diaUtilAnt = getDiaUtilAnterior(dtVenc);
           if (diaUtilAnt === hojeStr) {
               (t as any).antecipadoPorFeriado = true;
               return true;
           }
        }
        
        return false;
      });

      if (pendentesVencendo.length > 0) {
        setContasVencendo(pendentesVencendo);
        setIsOpen(true);
        playSound('aviso');
        
        // Notificação Nativa do Windows/Mac
        if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
           new Notification('Atenção: Contas Vencendo Hoje!', {
             body: `Você tem ${pendentesVencendo.length} conta(s) pendente(s) que exigem atenção hoje. Não perca o prazo!`,
             icon: '/icon.png'
           });
        }
      } else {
        setContasVencendo([]);
        setIsOpen(false);
      }
    } catch (err) {
      console.error("[DAILY POPUP CHECK ERROR]", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    // Pedir permissão para Notificações do SO
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }

    let intervalLimpar: NodeJS.Timeout | null = null;

    const iniciarVerificacao = async () => {
      const cfg = userId ? await import('@/lib/storage').then(m => m.getConfiguracoes(userId)).catch(() => null) : null;
      
      const apenasAoIniciar = cfg?.lembretesPopupAoIniciar ?? true;
      const horarios = cfg?.lembretesPopupHorarios || [];
      const hojeStr = new Date().toISOString().split('T')[0];
      const sessaoChave = `popup_mostrado_${hojeStr}`;

      // 1. Checar se deve mostrar na carga inicial (login / abertura do app)
      if (apenasAoIniciar) {
         if (!sessionStorage.getItem(sessaoChave)) {
            checarContasEAlertar();
            sessionStorage.setItem(sessaoChave, 'true');
         }
      } else {
         // Comportamento antigo: mostrava toda vez que recarregava a página
         checarContasEAlertar();
      }

      // 2. Loop para verificar os horários específicos agendados pelo usuário
      intervalLimpar = setInterval(() => {
         const agora = new Date();
         const hs = agora.getHours().toString().padStart(2, '0') + ':' + agora.getMinutes().toString().padStart(2, '0');
         
         if (horarios.includes(hs)) {
            const chaveMinuto = `popup_horario_${hojeStr}_${hs}`;
            if (!sessionStorage.getItem(chaveMinuto)) {
               checarContasEAlertar();
               sessionStorage.setItem(chaveMinuto, 'true');
            }
         }
         
         // Se o usuário não configurou horários específicos, mas ainda não pagou a conta:
         // A regra antiga era a cada 30min, mas como ele pediu "somente ao iniciar o sistema e não periodo que eu escolher",
         // não vamos mais mostrar a cada 30 min caso ele não defina os horários.
      }, 30000); // Roda a cada 30 segundos para ser preciso não minuto
    };

    iniciarVerificacao();

    return () => {
      if (intervalLimpar) clearInterval(intervalLimpar);
    };
  }, [checarContasEAlertar, userId]);

  const handleMarcarPagas = async () => {
    try {
      const hoje = new Date().toISOString().split('T')[0];
      for (const conta of contasVencendo) {
        await atualizarTransacao(conta.id, {
          status: 'pago',
          dataPagamento: hoje
        });
      }
      playSound('sucesso');
      setIsOpen(false);
      await checarContasEAlertar();
    } catch (e) {
      console.error("[DAILY POPUP PAY ERROR]", e);
    }
  };

  const handleIrParaLancamentos = () => {
    setIsOpen(false);
    if (setActiveTab) setActiveTab('lancamentos');
  };

  if (!isOpen || loading || contasVencendo.length === 0) return null;

  const total = contasVencendo.reduce((acc, c) => acc + c.valor, 0);
  const hojeStr = new Date().toISOString().split('T')[0];
  const temDoDia = contasVencendo.some(c => (c.dataVencimento || c.data) === hojeStr);
  const temAtrasadas = contasVencendo.some(c => (c.dataVencimento || c.data) < hojeStr);

  return (
    <div style={{
      position: 'fixed',
      inset: 0,
      zIndex: 999999,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      background: 'rgba(0,0,0,0.75)',
      backdropFilter: 'blur(12px)'
    }}>
      <div className="modal-box scale-up" style={{
        position: 'relative',
        width: '100%',
        maxWidth: 420,
        borderRadius: 24,
        padding: 0,
        overflow: 'hidden',
        boxShadow: '0 25px 60px rgba(0,0,0,0.7)',
        background: 'var(--bg-glass-strong)',
        border: '1px solid rgba(239, 68, 68, 0.4)'
      }}>
        {/* Top Header */}
        <div style={{
          background: 'linear-gradient(135deg, #ef4444, #f97316)',
          padding: '28px 24px',
          textAlign: 'center',
          position: 'relative'
        }}>
          <button
            onClick={() => setIsOpen(false)}
            style={{
              position: 'absolute',
              top: 14,
              right: 14,
              background: 'rgba(255,255,255,0.25)',
              border: 'none',
              color: 'white',
              borderRadius: '50%',
              width: 30,
              height: 30,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer'
            }}
          >
            <X size={16} />
          </button>

          <div style={{
            width: 68,
            height: 68,
            background: 'white',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px',
            boxShadow: '0 0 0 8px rgba(255,255,255,0.2), 0 10px 25px rgba(0,0,0,0.4)',
            animation: 'shake-bell 1s ease-in-out infinite'
          }}>
            <BellRing size={36} color="#ef4444" />
          </div>

          <h2 style={{ margin: 0, color: 'white', fontSize: 22, fontWeight: 900, letterSpacing: '-0.3px' }}>
            {temAtrasadas && temDoDia ? 'CONTAS VENCENDO E EM ATRASO!' : temDoDia ? 'CONTAS VENCENDO HOJE!' : 'CONTAS EM ATRASO!'}
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.92)', margin: '6px 0 0 0', fontSize: 13 }}>
            Existem {contasVencendo.length} lançamento(s) pendente(s) aguardando liquidação.
          </p>
        </div>

        {/* List Content */}
        <div style={{ padding: '24px 24px', background: 'var(--bg-glass)' }}>
          <div style={{
            background: 'rgba(239, 68, 68, 0.08)',
            border: '1px solid rgba(239, 68, 68, 0.2)',
            borderRadius: 16,
            padding: 16,
            marginBottom: 20,
            textAlign: 'center'
          }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
              Valor Total Pendente
            </span>
            <div style={{ fontSize: 26, fontWeight: 900, color: '#ef4444', marginTop: 2 }}>
              {formatarMoeda(total)}
            </div>
          </div>

          {/* List items */}
          <div style={{ maxHeight: 180, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 20 }}>
            {contasVencendo.map(c => {
              const dt = c.dataVencimento || c.data;
              const isHoje = dt === hojeStr;
              return (
                <div key={c.id} style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  background: 'var(--bg-card)',
                  border: `1px solid ${isHoje ? 'rgba(245,158,11,0.4)' : 'rgba(239,68,68,0.4)'}`,
                  borderRadius: 12,
                  padding: '10px 14px'
                }}>
                  <div style={{ flex: 1, minWidth: 0, paddingRight: 8 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--text-primary)', textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                      {c.descricao}
                    </div>
                    {(c as any).antecipadoPorFeriado ? (
                      <div style={{ fontSize: 11, color: '#3b82f6', fontWeight: 600, marginTop: 2, lineHeight: 1.2 }}>
                        📅 Vence {dt.split('-').reverse().join('/')}, mas sendo avisado antecipadamente por cair não Fim de Semana/Feriado.
                      </div>
                    ) : (
                      <div style={{ fontSize: 11, color: isHoje ? '#f59e0b' : '#ef4444', fontWeight: 600 }}>
                        {isHoje ? '⚡ Vence Hoje' : `⚠️ Atrasado desde ${dt.split('-').reverse().join('/')}`}
                      </div>
                    )}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 800, color: 'var(--text-primary)' }}>
                    {formatarMoeda(c.valor)}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <button
              onClick={handleMarcarPagas}
              className="btn-primary"
              style={{ width: '100%', justifyContent: 'center', height: 44, borderRadius: 12, background: 'linear-gradient(135deg, #10b981, #059669)', border: 'none' }}
            >
              <CheckCircle2 size={16} /> Confirmar Liquidação / Dar Baixa
            </button>
            <button
              onClick={handleIrParaLancamentos}
              style={{
                width: '100%',
                justifyContent: 'center',
                height: 44,
                borderRadius: 12,
                background: '#ffffff',
                color: '#1f2937',
                fontWeight: 800,
                fontSize: 14,
                border: '1px solid #e5e7eb',
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                cursor: 'pointer',
                boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
              }}
            >
              <span style={{ color: '#1f2937', fontWeight: 800 }}>Ir para Extrato / Lançamentos</span> <ArrowRight size={16} color="#1f2937" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
