import { collection, doc, getDocs, getDoc, setDoc, updateDoc, query, orderBy, serverTimestamp } from 'firebase/firestore';
import { getDb } from '@/lib/firebase';
import { gerarId } from '@/lib/storage';
import { LicencaMaster } from './tenantManager';

export interface FaturaSaaS {
  id: string;
  tenantId: string;
  clienteNome: string;
  dominio: string;
  valor: number;
  dataVencimento: string; // yyyy-MM-dd
  dataPagamento?: string; // yyyy-MM-dd
  status: 'pendente' | 'pago' | 'atrasado' | 'cancelada';
  descricao?: string;
  dataCriacao: Date;
}

/**
 * Obtém todas as faturas geradas no SaaS
 */
export async function getFaturasSaaS(): Promise<FaturaSaaS[]> {
  const db = getDb();
  const faturasRef = collection(db, 'admin_master_faturas');
  const q = query(faturasRef, orderBy('dataVencimento', 'desc'));
  const snap = await getDocs(q);
  
  return snap.docs.map(d => {
    const data = d.data();
    return {
      id: d.id,
      ...data,
      dataCriacao: data.dataCriacao?.toDate() || new Date()
    } as FaturaSaaS;
  });
}

/**
 * Cria uma nova fatura manual para um cliente
 */
export async function criarFaturaSaaS(
  faturaInfo: Omit<FaturaSaaS, 'id' | 'dataCriacao'>
): Promise<string> {
  const db = getDb();
  const id = gerarId();
  
  await setDoc(doc(db, 'admin_master_faturas', id), {
    ...faturaInfo,
    dataCriacao: serverTimestamp()
  });

  return id;
}

/**
 * Atualiza o status de uma fatura
 */
export async function atualizarStatusFaturaSaaS(
  faturaId: string, 
  status: 'pendente' | 'pago' | 'atrasado' | 'cancelada',
  dataPagamento?: string
) {
  const db = getDb();
  await setDoc(doc(db, 'admin_master_faturas', faturaId), {
    status,
    dataPagamento: dataPagamento || null,
    atualizadoEm: serverTimestamp()
  }, { merge: true });
}

/**
 * Dar baixa manual em uma fatura: muda status para 'pago', registra dataPagamento,
 * e renova a licença automaticamente por +diasRenovacao dias.
 */
export async function darBaixaFatura(
  faturaId: string,
  diasRenovacao: number = 30
): Promise<{ success: boolean; novoVencimento?: string; error?: string }> {
  try {
    const db = getDb();

    // 1. Buscar a fatura
    const faturaRef = doc(db, 'admin_master_faturas', faturaId);
    const faturaSnap = await getDoc(faturaRef);

    if (!faturaSnap.exists()) {
      return { success: false, error: 'Fatura não encontrada.' };
    }

    const faturaData = faturaSnap.data();
    const tenantId = faturaData.tenantId;

    if (!tenantId) {
      return { success: false, error: 'Fatura sem tenant associado.' };
    }

    // 2. Dar baixa na fatura
    const hoje = new Date();
    const dataPagamento = hoje.toISOString().substring(0, 10); // yyyy-MM-dd

    await updateDoc(faturaRef, {
      status: 'pago',
      dataPagamento,
      atualizadoEm: serverTimestamp()
    });

    // 3. Renovar a licença
    const licencaRef = doc(db, 'admin_master_licencas', tenantId);
    const licencaSnap = await getDoc(licencaRef);

    let novoVencimento: Date;

    if (licencaSnap.exists()) {
      const licencaData = licencaSnap.data();

      // Determinar base para cálculo do novo vencimento
      let dataBaseVenc: Date;
      if (licencaData.dataVencimento) {
        if (typeof licencaData.dataVencimento.toDate === 'function') {
          dataBaseVenc = licencaData.dataVencimento.toDate();
        } else {
          dataBaseVenc = new Date(licencaData.dataVencimento);
        }
      } else {
        dataBaseVenc = hoje;
      }

      // Se já está vencida, renovar a partir de hoje
      if (dataBaseVenc < hoje) {
        dataBaseVenc = hoje;
      }

      novoVencimento = new Date(dataBaseVenc);
      novoVencimento.setDate(novoVencimento.getDate() + diasRenovacao);

      await updateDoc(licencaRef, {
        dataVencimento: novoVencimento,
        status: 'ativa',
        atualizadoEm: serverTimestamp()
      });
    } else {
      // Licença não encontrada — calcular mesmo assim
      novoVencimento = new Date(hoje);
      novoVencimento.setDate(novoVencimento.getDate() + diasRenovacao);
    }

    return {
      success: true,
      novoVencimento: novoVencimento.toLocaleDateString('pt-BR')
    };

  } catch (error: any) {
    console.error('[BILLING] Erro ao dar baixa na fatura:', error);
    return { success: false, error: error.message || 'Erro desconhecido.' };
  }
}

/**
 * Gerar uma nova fatura para um cliente/tenant
 */
export async function gerarFaturaRecorrente(
  tenantId: string,
  clienteNome: string,
  dominio: string,
  valor: number,
  descricao: string,
  dataVencimento: string // yyyy-MM-dd
): Promise<string> {
  const db = getDb();
  const id = gerarId();

  await setDoc(doc(db, 'admin_master_faturas', id), {
    tenantId,
    clienteNome,
    dominio,
    valor,
    descricao,
    dataVencimento,
    status: 'pendente',
    dataCriacao: serverTimestamp()
  });

  return id;
}
