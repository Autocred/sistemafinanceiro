'use client';
import React, { useState, useEffect } from 'react';
import { getDb } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { LicencaMaster } from '@/lib/saas/tenantManager';
import Link from 'next/link';
import { Search, Shield, Building2, LifeBuoy, ArrowRight, Activity, Terminal } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function SuportePage() {
  const [licencas, setLicencas] = useState<LicencaMaster[]>([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState('');
  
  const router = useRouter();

  useEffect(() => {
    const q = query(collection(getDb(), 'admin_master_licencas'), orderBy('dataCriacao', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snap) => {
      const lista = snap.docs.map(d => {
        const data = d.data();
        return {
          id: d.id,
          ...data,
          nomeFantasia: String(data.nomeFantasia || 'Sem Nome'),
          dominio: String(data.dominio || ''),
          documento: String(data.documento || ''),
          status: String(data.status || 'Desconhecido'),
        };
      }) as LicencaMaster[];
      
      setLicencas(lista);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const licencasFiltradas = licencas.filter(l => {
    const nome = String(l.nomeFantasia || '').toLowerCase();
    const dom = String(l.dominio || '').toLowerCase();
    const docStr = String(l.documento || '');
    const term = String(busca || '').toLowerCase();
    return nome.includes(term) || dom.includes(term) || docStr.includes(term);
  });

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 bg-gray-50 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-gray-900 flex items-center gap-3">
            <LifeBuoy className="w-8 h-8 text-blue-600" />
            Central de Suporte & Atualizações
          </h1>
          <p className="text-gray-500 mt-1">Selecione um cliente abaixo para acessar dados de login, realizar suporte técnico e enviar atualizações.</p>
        </div>
      </div>

      {/* FILTER AREA */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Buscar por nome do cliente, domínio ou documento..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 text-gray-900 placeholder-gray-400 rounded-xl pl-10 pr-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
          />
        </div>
      </div>

      {/* LISTA DE CLIENTES */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
          <div className="col-span-full py-20 flex flex-col items-center justify-center gap-3">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <span className="text-gray-500 font-medium">Carregando lista de suporte...</span>
          </div>
        ) : licencasFiltradas.length === 0 ? (
          <div className="col-span-full py-20 text-center border-2 border-dashed border-gray-200 rounded-2xl bg-white">
            <LifeBuoy className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 font-medium text-lg">Nenhum cliente encontrado.</p>
          </div>
        ) : (
          licencasFiltradas.map((l) => (
            <div key={l.id} className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-all group flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center border border-blue-100 shrink-0 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900 text-lg group-hover:text-blue-600 transition-colors line-clamp-1">{l.nomeFantasia}</h3>
                    <p className="text-sm text-gray-500">{l.dominio}</p>
                  </div>
                </div>
                
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium">Status</span>
                    <span className={`px-2 py-0.5 rounded-md text-xs font-bold uppercase ${
                      l.status === 'ativa' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                    }`}>
                      {l.status}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-gray-500 font-medium">Versão</span>
                    <span className="text-gray-900 font-bold">1.0.0</span>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => router.push(`/master/suporte/${l.id}`)}
                className="w-full bg-gray-50 hover:bg-blue-600 hover:text-white text-gray-700 font-bold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                Painel de Suporte <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))
        )}
      </div>

    </div>
  );
}
