export const MASTER_CONFIG = {
  tenantId: 'master',
  nomeFantasia: 'FinPessoal Master ERP',
  nomeSistema: 'FinPessoal',
  logoUrl: '/icon.svg',
  faviconUrl: '/icon.svg',
  corPrincipal: '#cc092f',
  corHover: '#a30725',
  headerGradient: 'linear-gradient(135deg, #cc092f 0%, #800000 100%)',
};
