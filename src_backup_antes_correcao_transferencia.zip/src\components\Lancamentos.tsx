'use client';

import React, { useState, useEffect } from 'react';
import { deletarTransacao, formatarMoeda, subscribeTransacoes, subscribeFaturas } from '@/lib/storage';
import { Categoria, Conta, Fatura, Transacao } from '@/lib/types';
import { calcularTotais, isCartaoPendente, normalizeDate } from '@/lib/financialEngine';
import { FORMAS_PAGAMENTO_LABELS, STATUS_LABELS } from '@/lib/defaults';
import { DynamicIcon } from '@/components/DynamicIcon';
import { format, subMonths, addMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { PlusCircle, Search, Filter, ChevronLeft, ChevronRight, Trash2, Edit3, Download, RefreshCw, ArrowUpCircle, ArrowDownCircle, CheckSquare, Square, XCircle, AlertTriangle, DollarSign, ChevronDown, ChevronUp, Clock, Zap, Calendar as CalendarIcon, List, Repeat, Paperclip, CheckCircle2 } from 'lucide-react';
import { ordenarMovimentacoesDesc, ordenarVencimentosAsc } from '@/lib/sorting';

interface Props { onNovoLancamento: () => void; onEditarLancamento?: (t: Transacao) => void; filtroRapido?: string; }

export default function Lancamentos({ onNovoLancamento, onEditarLancamento, filtroRapido }: Props) {
  const [expandedRow, setExpandedRow] = useState<string | null>(null);
  const [transacoes, setTransacoes] = useState<Transacao[]>([]);
  const [faturas, setFaturas] = useState<Fatura[]>([]);
  const [cfgSenha, setCfgSenha] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [mes, setMes] = useState(new Date());
  const [busca, setBusca] = useState('');
  const [filtroData, setFiltroData] = useState<'lancamento' | 'vencimento'>('lancamento');

  // Filtros de Status/Tipo unificados em array (múltipla escolha)
  const [filtrosAtivos, setFiltrosAtivos] = useState<string[]>(['todos']);

  const [periodoFiltro, setPeriodoFiltro] = useState<'hoje' | '2dias' | 'semana' | 'mes' | 'anão' | 'todos' | 'data_especifica'>('mes'); // Fallback para mês para não assustar não primeiro carregamento
  const [dataEspecificaInicio, setDataEspecificaInicio] = useState<string>('');
  const [dataEspecificaFim, setDataEspecificaFim] = useState<string>('');


  // Seleção em lote
  const [selecionados, setSelecionados] = useState<Set<string>>(new Set());
  const [modoSelecao, setModoSelecao] = useState(false);
  const [deletandoLote, setDeletandoLote] = useState(false);
  const [confirmarExclusao, setConfirmarExclusao] = useState<'selecionados' | 'todos' | null>(null);

  useEffect(() => {
    let unsubT: () => void;
    let unsubF: () => void;
    (async () => {
      setLoading(true);
      const { getConfiguracoes } = await import('@/lib/storage');
      const cfg = await getConfiguracoes();
      if (cfg?.exigirSenha && cfg?.senha) setCfgSenha(cfg.senha);
      
      unsubT = subscribeTransacoes(data => setTransacoes(data));
      unsubF = subscribeFaturas(data => setFaturas(data));
      setLoading(false);
    })();
    return () => { if (unsubT) unsubT(); if (unsubF) unsubF(); };
  }, []);

  useEffect(() => {
    if (filtroRapido) {
      if (filtroRapido === 'hoje') {
        setPeriodoFiltro('hoje');
        setFiltrosAtivos(['pendente']);
        setFiltroData('vencimento');
      } else if (filtroRapido === '2dias') {
        setPeriodoFiltro('2dias');
        setFiltrosAtivos(['pendente']);
        setFiltroData('vencimento');
      } else if (filtroRapido === 'semana') {
        setPeriodoFiltro('semana');
        setFiltrosAtivos(['pendente']);
        setFiltroData('vencimento');
      } else if (filtroRapido === 'atrasado') {
        setPeriodoFiltro('todos');
        setFiltrosAtivos(['vencido']);
        setFiltroData('vencimento');
      }
    }
  }, [filtroRapido]);

  const mesStr = format(mes, 'yyyy-MM');

  const checkCartaoPendente = (t: Transacao) => {
    return isCartaoPendente(t, faturas);
  };

  // Filtrar base (todos, o filtro refinado cuida do resto)
  const filtradasBase = transacoes.filter(t => !(t.faturaId && t.descricao.startsWith('Juros/Multa')));

  const filtradasSemOrdem = filtradasBase.filter(t => {
    const rawRef = filtroData === 'lancamento' ? (t.dataPagamento || t.dataLancamento || t.data) : (t.dataVencimento || t.data);
    const dataRef = normalizeDate(rawRef);
    
    let nãoPeriodo = true;
    const hojeData = new Date();
    const hojeStr = format(hojeData, 'yyyy-MM-dd');
    if (periodoFiltro === 'hoje') {
      nãoPeriodo = dataRef === hojeStr;
    } else if (periodoFiltro === '2dias') {
      const doisDiasFrente = format(new Date(hojeData.getTime() + 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
      nãoPeriodo = dataRef > hojeStr && dataRef <= doisDiasFrente;
    } else if (periodoFiltro === 'semana') {
      const doisDiasFrente = format(new Date(hojeData.getTime() + 2 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
      const umaSemanaFrente = format(new Date(hojeData.getTime() + 7 * 24 * 60 * 60 * 1000), 'yyyy-MM-dd');
      nãoPeriodo = dataRef > doisDiasFrente && dataRef <= umaSemanaFrente;
    } else if (periodoFiltro === 'mes') {
      nãoPeriodo = String(dataRef || '').startsWith(mesStr);
    } else if (periodoFiltro === 'anão') {
      nãoPeriodo = String(dataRef || '').startsWith(mesStr.substring(0, 4));
    } else if (periodoFiltro === 'data_especifica') {
      const dataItem = dataRef || '';
      if (dataEspecificaInicio && dataEspecificaFim) {
        nãoPeriodo = dataItem >= dataEspecificaInicio && dataItem <= dataEspecificaFim;
      } else if (dataEspecificaInicio) {
        nãoPeriodo = dataItem >= dataEspecificaInicio;
      } else if (dataEspecificaFim) {
        nãoPeriodo = dataItem <= dataEspecificaFim;
      } else {
        nãoPeriodo = true; // Se não selecionãou nada, mostra tudo (ou poderia não mostrar nada)
      }
    }

    // Pesquisa Inteligente Unificada
    const matchBusca = !busca || [
      t.descricao, t.fornecedorNome, t.clienteNome, t.categoriaNome, t.contaNome, t.observacoes, String(t.valor)
    ].some(v => v?.toLowerCase()?.includes(busca.toLowerCase()));
    
    // Múltipla escolha:
    const showAll = filtrosAtivos.includes('todos');
    
    // Tipo:
    const checkReceita = filtrosAtivos.includes('receita');
    const checkDespesa = filtrosAtivos.includes('despesa');
    let matchTipo = true;
    if (!showAll && (checkReceita || checkDespesa)) {
      matchTipo = (checkReceita && t.tipo === 'receita') || (checkDespesa && t.tipo === 'despesa');
    }

    // Status:
    const checkPago = filtrosAtivos.includes('pago');
    const checkPendente = filtrosAtivos.includes('pendente');
    const checkVencido = filtrosAtivos.includes('vencido');
    let matchStatus = true;
    if (!showAll && (checkPago || checkPendente || checkVencido)) {
      const isPago = t.status === 'pago';
      let isPend = false;
      if (t.formaPagamento === 'cartao_credito') {
        isPend = checkCartaoPendente(t);
      } else {
        isPend = t.status === 'pendente' || t.status === 'atrasado';
      }
      const dVenc = normalizeDate(t.dataVencimento || t.data || '');
      const isVenc = (t.status === 'atrasado' || t.status === 'pendente') && dVenc !== '' && dVenc < hojeStr;
      
      matchStatus = (checkPago && isPago) || (checkPendente && isPend) || (checkVencido && isVenc);
    }
    
    // Recorrente:
    const checkRecorrente = filtrosAtivos.includes('recorrente');
    let matchRecorrente = true;
    if (!showAll && checkRecorrente) {
      matchRecorrente = t.recorrente === true;
    }

    return nãoPeriodo && matchBusca && matchTipo && matchStatus && matchRecorrente;
  });

  const filtradas = filtroData === 'vencimento' 
    ? ordenarVencimentosAsc(filtradasSemOrdem)
    : ordenarMovimentacoesDesc(filtradasSemOrdem);

  const {
    totalReceitas,
    despesasPagas,
    despesasPendentesCartao,
    despesasPendentesComuns,
    despesasAPagarTotal: despesasAPagar,
    totalDespesas,
    saldoProjetado: saldo
  } = calcularTotais(filtradas, faturas);
  const fmt = formatarMoeda;

  const checkSenha = () => {
    if (!cfgSenha) return true;
    const s = window.prompt('Digite a senha de segurança para continuar:');
    if (s === cfgSenha) return true;
    if (s !== null) window.alert('Senha incorreta!');
    return false;
  };

  // Seleção
  const toggleSelecionado = (id: string) => {
    setSelecionados(prev => {
      const novo = new Set(prev);
      if (novo.has(id)) novo.delete(id);
      else novo.add(id);
      return novo;
    });
  };

  const selecionarTodos = () => {
    if (selecionados.size === filtradas.length) {
      setSelecionados(new Set());
    } else {
      setSelecionados(new Set(filtradas.map(t => t.id)));
    }
  };

  const cancelarSelecao = () => {
    setSelecionados(new Set());
    setModoSelecao(false);
  };

  const checarFaturaPaga = (faturaId?: string) => {
    if (!faturaId) return true;
    const fat = faturas.find(f => f.id === faturaId);
    if (fat && fat.status === 'paga') {
      const p = window.prompt('Fatura já paga! Digite a senha (1020) para alterar:');
      if (p !== '1020') {
        if (p !== null) alert('Senha incorreta.');
        return false;
      }
    }
    return true;
  };

  // Deletar individual
  const handleDeletar = async (id: string) => {
    const t = transacoes.find(x => x.id === id);
    if (t && !checarFaturaPaga(t.faturaId)) return;
    if (!checkSenha()) return;
    if (!confirm('Deletar este lançamento?')) return;
    await deletarTransacao(id);
    selecionados.delete(id);
    setSelecionados(new Set(selecionados));
  };

  const handleEditar = (t: Transacao) => {
    if (!checarFaturaPaga(t.faturaId)) return;
    if (onEditarLancamento) onEditarLancamento(t);
  };

  const handleMarcarPago = async (t: Transacao) => {
    if (!checarFaturaPaga(t.faturaId)) return;
    try {
      let novaContaId = t.contaId;
      let novaFormaPgto = t.formaPagamento;

      if (!novaContaId) {
        const cId = window.prompt(`Qual a conta para este lançamento?`);
        if (cId === null) return;
        novaContaId = cId;
      }
      
      if (!novaFormaPgto) {
        const fPgto = window.prompt(`Qual a forma de pagamento? (pix, boleto, transferencia, dinheiro)`);
        if (fPgto === null) return;
        novaFormaPgto = fPgto as any;
      }

      const hoje = format(new Date(), 'yyyy-MM-dd');
      const dataSugerida = (t.dataVencimento && t.dataVencimento <= hoje) ? t.dataVencimento : hoje;
      const dataPagamentoStr = window.prompt(`Data efetiva do pagamento/recebimento (YYYY-MM-DD):`, dataSugerida);
      if (dataPagamentoStr === null) return; // Cancelou
      
      const { atualizarTransacao } = await import('@/lib/storage');
      await atualizarTransacao(t.id, { 
        status: 'pago', 
        dataPagamento: dataPagamentoStr,
        contaId: novaContaId,
        formaPagamento: novaFormaPgto
      });
    } catch (err: any) {
      alert(err.message || 'Erro ao marcar pagamento.');
    }
  };

  // Deletar selecionados em lote
  const handleDeletarSelecionados = async () => {
    const ids = Array.from(selecionados);
    const trans = ids.map(id => transacoes.find(x => x.id === id));
    const hasPaga = trans.some(t => t && t.faturaId && faturas.find(f => f.id === t.faturaId)?.status === 'paga');
    if (hasPaga) {
      const p = window.prompt('Alguns lançamentos pertencem a faturas pagas! Digite a senha (1020) para excluir:');
      if (p !== '1020') {
        if (p !== null) alert('Senha incorreta.');
        return;
      }
    }
    if (!checkSenha()) return;
    setDeletandoLote(true);
    const idsToDel = Array.from(selecionados);
    for (const id of idsToDel) {
      await deletarTransacao(id);
    }
    setSelecionados(new Set());
    setModoSelecao(false);
    setConfirmarExclusao(null);
    setDeletandoLote(false);
  };

  // Deletar todos visíveis
  const handleDeletarTodos = async () => {
    const hasPaga = filtradas.some(t => t && t.faturaId && faturas.find(f => f.id === t.faturaId)?.status === 'paga');
    if (hasPaga) {
      const p = window.prompt('Alguns lançamentos pertencem a faturas pagas! Digite a senha (1020) para excluir:');
      if (p !== '1020') {
        if (p !== null) alert('Senha incorreta.');
        return;
      }
    }
    if (!checkSenha()) return;
    setDeletandoLote(true);
    for (const t of filtradas) {
      await deletarTransacao(t.id);
    }
    setSelecionados(new Set());
    setModoSelecao(false);
    setConfirmarExclusao(null);
    setDeletandoLote(false);
  };

  const exportarCSV = () => {
    const header = 'Tipo,Descrição,Valor,Data,Categoria,Fornecedor,Conta,Forma Pgto,Status';
    const rows = filtradas.map(t =>
      `${t.tipo},"${t.descricao}",${t.valor},${t.data},"${t.categoriaNome || ''}","${t.fornecedorNome || ''}","${t.contaNome || ''}",${t.formaPagamento},${t.status}`
    );
    const csv = [header, ...rows].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `lancamentos-${mesStr}.csv`;
    a.click();
  };

  // Categorias únicas do mês
  const categorias = [...new Set(transacoes.filter(t => String(t.data || '').startsWith(mesStr)).map(t => t.categoriaId))];
  const categoriasNomes = transacoes.reduce((acc, t) => {
    if (t.categoriaId && t.categoriaNome) acc[t.categoriaId] = t.categoriaNome;
    return acc;
  }, {} as Record<string, string>);

  const todosSelected = filtradas.length > 0 && selecionados.size === filtradas.length;
  const algunsSelected = selecionados.size > 0 && selecionados.size < filtradas.length;

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <h1 style={{ fontSize: 24, fontWeight: 800, color: 'var(--text-primary)', letterSpacing: '-0.5px' }}>Lançamentos</h1>
        <div style={{ display: 'flex', gap: 10 }}>
          <button onClick={exportarCSV} className="btn-secondary" title="Exportar CSV">
            <Download size={15} />
          </button>
        </div>
      </div>

      {/* Removidas as abas, agora é tudo unificado nãos botões de filtro abaixo */}

      {/* Filtros Rápidos (Bancários) e Pesquisa */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 20 }}>
        {/* Filtros de Período */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4, WebkitOverflowScrolling: 'touch' }}>
          {[
            { id: 'hoje', label: 'Hoje' },
            { id: '2dias', label: 'Até 2 dias' },
            { id: 'semana', label: 'Semana' },
            { id: 'mes', label: 'Mês' },
            { id: 'anão', label: 'Anão' },
            { id: 'data_especifica', label: 'Data Específica' },
            { id: 'todos', label: 'Todos Períodos' }
          ].map(f => (
            <button 
              key={f.id}
              onClick={() => setPeriodoFiltro(f.id as any)}
              style={{
                padding: '6px 14px', borderRadius: 20,
                background: periodoFiltro === f.id ? 'var(--text-primary)' : 'var(--bg-secondary)',
                color: periodoFiltro === f.id ? 'var(--bg-primary)' : 'var(--text-primary)',
                border: `1px solid ${periodoFiltro === f.id ? 'var(--text-primary)' : 'var(--border)'}`,
                fontSize: 12, fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap',
                transition: 'all 0.2s ease-in-out'
              }}>
              {f.label}
            </button>
          ))}
          
          {periodoFiltro === 'data_especifica' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-secondary)', padding: '4px 12px', borderRadius: 20, border: '1px solid var(--border)' }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)' }}>De:</span>
              <input
                type="date"
                value={dataEspecificaInicio}
                onChange={(e) => setDataEspecificaInicio(e.target.value)}
                style={{
                  background: 'transparent',
                  color: 'var(--text-primary)',
                  border: 'none',
                  fontSize: 12,
                  fontWeight: 700,
                  outline: 'none',
                  cursor: 'pointer'
                }}
              />
              <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-muted)' }}>Até:</span>
              <input
                type="date"
                value={dataEspecificaFim}
                onChange={(e) => setDataEspecificaFim(e.target.value)}
                style={{
                  background: 'transparent',
                  color: 'var(--text-primary)',
                  border: 'none',
                  fontSize: 12,
                  fontWeight: 700,
                  outline: 'none',
                  cursor: 'pointer'
                }}
              />
            </div>
          )}
        </div>

        {/* Filtros de Status/Tipo (Fase 6 do Arquitetura) */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 4, WebkitOverflowScrolling: 'touch' }}>
          {[
            { id: 'todos', label: 'Todos os Tipos' },
            { id: 'receita', label: 'Receitas' },
            { id: 'despesa', label: 'Despesas' },
            { id: 'pago', label: 'Pagos / Recebidos' },
            { id: 'pendente', label: 'Pendentes' },
            { id: 'vencido', label: 'Vencidos' },
            { id: 'recorrente', label: 'Recorrentes' }
          ].map(f => {
            const isActive = filtrosAtivos.includes(f.id);
            return (
              <button 
                key={f.id}
                onClick={() => {
                  if (f.id === 'todos') {
                    setFiltrosAtivos(['todos']);
                  } else {
                    let next = [...filtrosAtivos];
                    if (next.includes('todos')) next = [];
                    
                    if (next.includes(f.id)) {
                      next = next.filter(x => x !== f.id);
                      if (next.length === 0) next = ['todos'];
                    } else {
                      next.push(f.id);
                    }
                    setFiltrosAtivos(next);
                  }
                }}
                style={{
                  padding: '6px 14px', borderRadius: 20,
                  background: isActive ? '#0284c7' : 'var(--bg-secondary)',
                  color: isActive ? 'white' : 'var(--text-primary)',
                  border: `1px solid ${isActive ? '#0284c7' : 'var(--border)'}`,
                  fontSize: 12, fontWeight: 700, cursor: 'pointer', whiteSpace: 'nowrap'
                }}>
                {f.label}
              </button>
            );
          })}
        </div>

        {/* Pesquisa Instantânea e Seleção de Data */}
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', background: 'var(--bg-secondary)', border: '1px solid var(--border)', borderRadius: 12, padding: '8px 14px', flex: 1, minWidth: 220 }}>
            <Search size={16} color="var(--text-muted)" style={{ marginRight: 8 }} />
            <input 
              type="text" 
              placeholder="Pesquisa instantânea (descrição, valor, categoria, conta...)" 
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              style={{ border: 'none', background: 'transparent', outline: 'none', width: '100%', color: 'var(--text-primary)', fontSize: 13 }}
            />
          </div>
          <select 
            className="input-field" 
            style={{ width: 'auto', minWidth: 160, padding: '8px 12px', fontSize: 13, borderRadius: 12 }} 
            value={filtroData} 
            onChange={e => setFiltroData(e.target.value as any)}
          >
            <option value="lancamento">Data: Lançamento</option>
            <option value="vencimento">Data: Vencimento</option>
          </select>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 10 }}>
          {/* Botão de modo seleção */}
          <button
            onClick={() => {
              if (modoSelecao) cancelarSelecao();
              else setModoSelecao(true);
            }}
            className="btn-secondary"
            style={{
              background: modoSelecao ? 'rgba(239,68,68,0.1)' : undefined,
              color: modoSelecao ? '#f87171' : undefined,
              borderColor: modoSelecao ? 'rgba(239,68,68,0.3)' : undefined,
            }}
            title={modoSelecao ? 'Cancelar seleção' : 'Selecionar para excluir'}
          >
            {modoSelecao ? <XCircle size={15} /> : <CheckSquare size={15} />}
          </button>
        </div>
      </div>

      {/* Barra de ações em lote */}
      {modoSelecao && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12,
          background: 'rgba(239,68,68,0.06)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 12,
          padding: '12px 20px', marginBottom: 16,
          animation: 'fadeIn 0.2s ease',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 14, fontWeight: 700, color: '#f87171' }}>
              {selecionados.size} {selecionados.size === 1 ? 'selecionado' : 'selecionados'}
            </span>
            <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>de {filtradas.length}</span>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={selecionarTodos}
              className="btn-secondary" style={{ fontSize: 12, padding: '6px 14px' }}>
              {todosSelected ? 'Desmarcar Todos' : 'Selecionar Todos'}
            </button>
            <button
              onClick={() => setConfirmarExclusao('selecionados')}
              disabled={selecionados.size === 0}
              className="btn-danger"
              style={{
                fontSize: 12, padding: '6px 14px',
                opacity: selecionados.size === 0 ? 0.4 : 1,
                cursor: selecionados.size === 0 ? 'not-allowed' : 'pointer',
              }}
            >
              <Trash2 size={13} />
              Excluir Selecionados ({selecionados.size})
            </button>
            <button
              onClick={() => setConfirmarExclusao('todos')}
              className="btn-danger"
              style={{ fontSize: 12, padding: '6px 14px', background: 'linear-gradient(135deg, #dc2626, #991b1b)' }}
            >
              <Trash2 size={13} />
              Excluir Todos ({filtradas.length})
            </button>
            <button onClick={cancelarSelecao}
              className="btn-secondary" style={{ fontSize: 12, padding: '6px 14px' }}>
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Modal de confirmação */}
      {confirmarExclusao && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setConfirmarExclusao(null)}>
          <div className="modal-box slide-up" style={{ maxWidth: 440, textAlign: 'center', padding: 32 }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(239,68,68,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px' }}>
              <AlertTriangle size={28} color="#ef4444" />
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 700, color: 'var(--text-primary)', marginBottom: 8 }}>
              Confirmar Exclusão
            </h3>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 6 }}>
              {confirmarExclusao === 'todos'
                ? `Você está prestes a excluir TODOS os ${filtradas.length} lançamentos do período filtrado.`
                : `Você está prestes a excluir ${selecionados.size} lançamento(s) selecionado(s).`
              }
            </p>
            <p style={{ fontSize: 13, color: '#ef4444', fontWeight: 600, marginBottom: 24 }}>
              ⚠️ Esta ação não pode ser desfeita!
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center' }}>
              <button onClick={() => setConfirmarExclusao(null)} className="btn-secondary" style={{ flex: 1 }}>
                Cancelar
              </button>
              <button
                onClick={confirmarExclusao === 'todos' ? handleDeletarTodos : handleDeletarSelecionados}
                disabled={deletandoLote}
                className="btn-danger"
                style={{ flex: 1, justifyContent: 'center' }}
              >
                {deletandoLote ? (
                  <>⏳ Excluindo...</>
                ) : (
                  <><Trash2 size={15} /> Sim, Excluir</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navegação de Mês (Escondida se o filtro não for por Mês, pois os botões rápidos controlam isso agora) */}
      {periodoFiltro === 'mes' && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', background: 'var(--bg-glass)', border: '1px solid var(--border)', borderRadius: 12, padding: '12px 20px', marginBottom: 20 }}>
          <button onClick={() => setMes(m => subMonths(m, 1))} className="btn-secondary" style={{ padding: '6px 10px' }}>
            <ChevronLeft size={16} />
          </button>
          <div style={{ textAlign: 'center' }}>
            <p style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)', textTransform: 'capitalize' }}>
              {format(mes, "MMMM 'de' yyyy", { locale: ptBR })}
            </p>
            <p style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{filtradas.length} lançamentos</p>
          </div>
          <button onClick={() => setMes(m => addMonths(m, 1))} className="btn-secondary" style={{ padding: '6px 10px' }}>
            <ChevronRight size={16} />
          </button>
        </div>
      )}

      {/* Resumo rápido */}
      <div className="grid-responsive-4" style={{ marginBottom: 20 }}>
        <div style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.15)', borderRadius: 12, padding: '14px 16px', textAlign: 'center' }}>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>Receitas</p>
          <p style={{ fontSize: 20, fontWeight: 800, color: '#10b981' }}>{fmt(totalReceitas)}</p>
        </div>
        <div style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.15)', borderRadius: 12, padding: '14px 16px', textAlign: 'center' }}>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>Despesas Pagas</p>
          <p style={{ fontSize: 20, fontWeight: 800, color: '#ef4444' }}>{fmt(despesasPagas)}</p>
        </div>
        <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.15)', borderRadius: 12, padding: '14px 16px', textAlign: 'center' }}>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>Despesas a Pagar</p>
          <p style={{ fontSize: 20, fontWeight: 800, color: '#f59e0b' }}>{fmt(despesasAPagar)}</p>
        </div>
        <div style={{ background: saldo >= 0 ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.08)', border: `1px solid ${saldo >= 0 ? 'rgba(16,185,129,0.15)' : 'rgba(239,68,68,0.15)'}`, borderRadius: 12, padding: '14px 16px', textAlign: 'center' }}>
          <p style={{ fontSize: 11, color: 'var(--text-muted)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: 4 }}>Saldo</p>
          <p style={{ fontSize: 20, fontWeight: 800, color: saldo >= 0 ? '#10b981' : '#ef4444' }}>{fmt(saldo)}</p>
        </div>
      </div>



      {/* Tabela */}
      <div className="glass" style={{ overflow: 'hidden' }}>
        {loading ? (
          <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
            Carregando...
          </div>
        ) : filtradas.length === 0 ? (
          <div style={{ padding: 60, textAlign: 'center', color: 'var(--text-muted)' }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>📭</div>
            <p style={{ fontSize: 16, fontWeight: 600, color: 'var(--text-muted)', marginBottom: 8 }}>Nenhum lançamento encontrado</p>
            <p style={{ fontSize: 13 }}>Tente ajustar os filtros ou adicione um novo lançamento.</p>
            <button onClick={onNovoLancamento} className="btn-primary" style={{ margin: '20px auto 0', display: 'inline-flex' }}>
              <PlusCircle size={16} />
              Novo Lançamento
            </button>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  {modoSelecao && (
                    <th style={{ width: 40 }}>
                      <button onClick={selecionarTodos}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2, display: 'flex', alignItems: 'center' }}
                        title={todosSelected ? 'Desmarcar todos' : 'Selecionar todos'}>
                        {todosSelected ? (
                          <CheckSquare size={16} color="#10b981" />
                        ) : algunsSelected ? (
                          <div style={{ width: 16, height: 16, borderRadius: 3, border: '2px solid #10b981', background: 'rgba(16,185,129,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                            <div style={{ width: 8, height: 2, background: '#10b981', borderRadius: 1 }} />
                          </div>
                        ) : (
                          <Square size={16} color="var(--text-muted)" />
                        )}
                      </button>
                    </th>
                  )}
                  <th>Tipo</th>
                  <th>Descrição</th>
                  <th className="hide-mobile">Categoria</th>
                  <th className="hide-mobile">Fornecedor</th>
                  <th>Valor</th>
                  <th>Data</th>
                  <th className="hide-mobile">Forma</th>
                  <th className="hide-mobile">Conta</th>
                  <th>Status</th>
                  <th className="hide-mobile">Ações</th>
                  <th className="mobile-only-cell" style={{ width: 40 }}></th>
                </tr>
              </thead>
              <tbody>
                {filtradas.map(t => {
                  const hoje = new Date();
                  const diff = Math.ceil((new Date(t.data).getTime() - hoje.getTime()) / (1000 * 3600 * 24));
                  let alertaCss = '';
                  if (t.tipo === 'despesa' && t.status !== 'pago') {
                    if (diff < 0) alertaCss = 'piscar-vermelho';
                    else if (diff === 0) alertaCss = 'piscar-vermelho';
                    else if (diff <= 2) alertaCss = 'piscar-laranja';
                  }

                  return (
                    <React.Fragment key={t.id}>
                    <tr className={alertaCss} style={{
                      background: selecionados.has(t.id) ? 'rgba(239,68,68,0.06)' : undefined,
                      transition: 'background 0.15s',
                    }}>
                      {modoSelecao && (
                        <td>
                          <button onClick={() => toggleSelecionado(t.id)}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 2, display: 'flex', alignItems: 'center' }}>
                            {selecionados.has(t.id)
                              ? <CheckSquare size={16} color="#10b981" />
                              : <Square size={16} color="var(--text-muted)" />
                            }
                          </button>
                        </td>
                      )}
                      <td>
                        <div style={{ width: 28, height: 28, borderRadius: '50%', background: t.tipo === 'transferencia' ? 'rgba(2,132,199,0.12)' : t.tipo === 'receita' ? 'rgba(22,163,74,0.12)' : 'rgba(185,28,28,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          {t.tipo === 'transferencia' ? <RefreshCw size={14} color="#0284c7" /> : t.tipo === 'receita'
                            ? <ArrowUpCircle size={14} color="#15803d" />
                            : <ArrowDownCircle size={14} color="#8b0000" />}
                        </div>
                      </td>
                      <td>
                        <div>
                          <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: 6 }}>
                            {t.descricao}
                            {t.conciliado && <span title="Conciliado"><CheckCircle2 size={14} color="#10b981" /></span>}
                            {t.comprovanteBase64 && <span title="Possui Comprovante"><Paperclip size={14} color="#3b82f6" /></span>}
                          </p>
                          {t.parcelado && <span style={{ fontSize: 10, color: '#8b5cf6' }}>📦 {t.parcelaAtual}/{t.totalParcelas}x</span>}
                          {t.recorrente && <span style={{ fontSize: 10, color: '#f59e0b' }}> 🔄 Recorrente</span>}
                        </div>
                      </td>
                      <td className="hide-mobile">
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
                          <DynamicIcon name={t.tipo === 'transferencia' ? 'RefreshCw' : (t.categoriaIcone || 'Package')} size={14} />
                          <span style={{ color: t.tipo === 'transferencia' ? '#3b82f6' : (t.categoriaCor || 'var(--text-secondary)') }}>{t.tipo === 'transferencia' ? 'Transferência' : t.categoriaNome}</span>
                        </span>
                      </td>
                      <td className="hide-mobile" style={{ fontSize: 13, color: 'var(--text-secondary)' }}>{t.tipo === 'transferencia' ? (t.contaDestinoNome ? `Para: ${t.contaDestinoNome}` : '—') : (t.fornecedorNome || t.clienteNome || '—')}</td>
                      <td>
                        <span style={{ fontSize: 14, fontWeight: 700, color: t.tipo === 'transferencia' ? '#0284c7' : (t.tipo === 'receita' ? '#15803d' : '#8b0000') }}>
                          {t.tipo === 'despesa' ? '−' : t.tipo === 'receita' ? '+' : ''}{fmt(t.valor)}
                        </span>
                      </td>
                      <td>
                        <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                          <span>{String(t.data || '').split('-').reverse().join('/')}</span>
                          
                          {/* Contador de Dias Modernão */}
                          {t.status !== 'pago' && t.tipo !== 'transferencia' && (
                            <span style={{
                              background: t.tipo === 'despesa' ? '#ef4444' : '#10b981',
                              color: 'white',
                              padding: '2px 8px',
                              borderRadius: 12,
                              fontSize: 10,
                              fontWeight: 800,
                              textTransform: 'uppercase',
                              letterSpacing: '0.5px',
                              display: 'inline-flex',
                              alignItems: 'center',
                              boxShadow: `0 2px 4px ${t.tipo === 'despesa' ? 'rgba(239,68,68,0.4)' : 'rgba(16,185,129,0.4)'}`
                            }}>
                              {(() => {
                                const diff = Math.ceil((new Date(t.data).getTime() - new Date().getTime()) / (1000 * 3600 * 24));
                                if (diff < 0) return `Atrasado ${Math.abs(diff)} dia${Math.abs(diff) > 1 ? 's' : ''}`;
                                if (diff === 0) return 'Hoje';
                                return `Falta${diff > 1 ? 'm' : ''} ${diff} dia${diff > 1 ? 's' : ''}`;
                              })()}
                            </span>
                          )}
                        </p>
                      </td>
                      <td className="hide-mobile">
                        <span className="badge badge-gray" style={{ fontSize: 10 }}>
                          {FORMAS_PAGAMENTO_LABELS[t.formaPagamento] || t.formaPagamento}
                        </span>
                      </td>
                      <td className="hide-mobile" style={{ fontSize: 12, color: 'var(--text-secondary)' }}>{t.contaNome || '—'}</td>
                      <td>
                        {checkCartaoPendente(t) ? (
                          <span className="badge badge-yellow" style={{ fontSize: 10 }}>Fatura Aberta</span>
                        ) : (
                          <span className={`badge ${t.status === 'pago' ? 'badge-green' : t.status === 'atrasado' ? 'badge-red' : 'badge-yellow'}`} style={{ fontSize: 10 }}>
                            {STATUS_LABELS[t.tipo]?.[t.status] || t.status}
                          </span>
                        )}
                      </td>
                      <td className="hide-mobile">
                        <div style={{ display: 'flex', gap: 6 }}>
                          {!checkCartaoPendente(t) && t.status !== 'pago' && t.formaPagamento !== 'cartao_credito' && (
                            <>
                              <button
                                onClick={() => handleMarcarPago(t)}
                                style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)', borderRadius: 7, padding: '4px 8px', cursor: 'pointer', color: '#10b981', transition: 'all 0.15s' }}
                                title="Pagamento Rápido (Marcar como Pago agora)">
                                <CheckSquare size={13} />
                              </button>
                              <button
                                onClick={() => handleEditar(t)}
                                style={{ background: 'rgba(245,158,11,0.1)', border: '1px solid rgba(245,158,11,0.2)', borderRadius: 7, padding: '4px 8px', cursor: 'pointer', color: '#f59e0b', transition: 'all 0.15s' }}
                                title="Conferir e Pagar (Abrir detalhes)">
                                <DollarSign size={13} />
                              </button>
                            </>
                          )}
                          <button
                            onClick={() => handleEditar(t)}
                            style={{ background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 7, padding: '4px 8px', cursor: 'pointer', color: '#3b82f6', transition: 'all 0.15s' }}
                            title="Editar">
                            <Edit3 size={13} />
                          </button>
                          <button
                            onClick={() => handleDeletar(t.id)}
                            style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 7, padding: '4px 8px', cursor: 'pointer', color: '#f87171', transition: 'all 0.15s' }}
                            title="Deletar">
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                      <td className="mobile-only-cell">
                        <button onClick={() => setExpandedRow(expandedRow === t.id ? null : t.id)} style={{ background: 'none', border: 'none', padding: 8, color: 'var(--text-muted)' }}>
                           {expandedRow === t.id ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                        </button>
                      </td>
                    </tr>
                    {expandedRow === t.id && (
                      <tr className="mobile-only-row" style={{ background: 'var(--bg-active)' }}>
                        <td colSpan={modoSelecao ? 7 : 6} style={{ padding: '16px', borderBottom: '1px solid var(--border)' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                              <div>
                                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{t.tipo === 'transferencia' ? 'Tipo' : 'Categoria'}</p>
                                <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 600 }}>{t.tipo === 'transferencia' ? 'Transferência' : t.categoriaNome}</p>
                              </div>
                              <div>
                                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{t.tipo === 'receita' ? 'Cliente' : t.tipo === 'transferencia' ? 'Conta Destinoão' : 'Fornecedor'}</p>
                                <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 600 }}>{t.tipo === 'transferencia' ? (t.contaDestinoNome || '—') : (t.fornecedorNome || t.clienteNome || '—')}</p>
                              </div>
                              <div>
                                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>Forma Pgto</p>
                                <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 600 }}>{FORMAS_PAGAMENTO_LABELS[t.formaPagamento] || t.formaPagamento}</p>
                              </div>
                              <div>
                                <p style={{ fontSize: 11, color: 'var(--text-muted)' }}>{t.tipo === 'transferencia' ? 'Conta Origem' : 'Conta'}</p>
                                <p style={{ fontSize: 13, color: 'var(--text-primary)', fontWeight: 600 }}>{t.contaNome || '—'}</p>
                              </div>
                            </div>
                            <div style={{ display: 'flex', gap: 8, marginTop: 8, flexWrap: 'wrap' }}>
                              {!checkCartaoPendente(t) && t.status !== 'pago' && t.formaPagamento !== 'cartao_credito' && (
                                <>
                                  <button onClick={() => handleMarcarPago(t)} className="btn-primary" style={{ flex: 1, padding: '8px', fontSize: 12, justifyContent: 'center' }}>
                                    <CheckSquare size={14} /> Pagar Rápido
                                  </button>
                                  <button onClick={() => handleEditar(t)} className="btn-secondary" style={{ flex: 1, padding: '8px', fontSize: 12, justifyContent: 'center', borderColor: '#f59e0b', color: '#f59e0b' }}>
                                    <DollarSign size={14} /> Conferir
                                  </button>
                                </>
                              )}
                              <button onClick={() => handleEditar(t)} className="btn-secondary" style={{ flex: 1, padding: '8px', fontSize: 12, justifyContent: 'center', borderColor: '#3b82f6', color: '#3b82f6' }}>
                                <Edit3 size={14} /> Editar
                              </button>
                              <button onClick={() => handleDeletar(t.id)} className="btn-secondary" style={{ flex: 1, padding: '8px', fontSize: 12, justifyContent: 'center', borderColor: '#ef4444', color: '#ef4444' }}>
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Total rodapé */}
      {filtradas.length > 0 && (
        <div style={{ marginTop: 12, textAlign: 'right', color: 'var(--text-muted)', fontSize: 13 }}>
          {filtradas.length} lançamentos · Total receitas: <strong style={{ color: '#10b981' }}>{fmt(totalReceitas)}</strong> · Total despesas: <strong style={{ color: '#f87171' }}>{fmt(totalDespesas)}</strong>
        </div>
      )}
    </div>
  );
}
