'use client';
import React from 'react';
import { Database, Download, Clock, RotateCcw } from 'lucide-react';

export default function BackupsPage() {
  const backups = [
    { data: 'Hoje, 03:00', tamanho: '4.2 GB', tipo: 'Automático', status: 'Concluído' },
    { data: 'Ontem, 03:00', tamanho: '4.1 GB', tipo: 'Automático', status: 'Concluído' },
    { data: '04 Ago, 18:45', tamanho: '4.1 GB', tipo: 'Manual', status: 'Concluído' },
    { data: '04 Ago, 03:00', tamanho: '4.0 GB', tipo: 'Automático', status: 'Concluído' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700 min-w-0">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">Backups Globais</h1>
          <p className="text-[var(--text-secondary)] mt-1">Gerencie os snapshots do banco de dados principal de todos os clientes.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium">
          <Database className="w-4 h-4" /> Gerar Backup Agora
        </button>
      </div>

      <div className="glass-panel p-6 rounded-2xl border border-[var(--border)]">
        <div className="flex items-center gap-4 mb-8 p-4 bg-emerald-500/10 rounded-xl border border-emerald-500/20">
          <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-500 shrink-0">
            <CheckCircleIcon className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-emerald-500">Rotina de Backup Ativa</h3>
            <p className="text-xs text-emerald-600/80 dark:text-emerald-400/80">Próximo backup programado para amanhã às 03:00.</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[600px]">
            <thead className="border-b border-[var(--border)]">
              <tr>
                <th className="pb-4 font-semibold text-[var(--text-secondary)]">Data e Hora</th>
                <th className="pb-4 font-semibold text-[var(--text-secondary)]">Tamanho</th>
                <th className="pb-4 font-semibold text-[var(--text-secondary)]">Gatilho</th>
                <th className="pb-4 font-semibold text-[var(--text-secondary)]">Status</th>
                <th className="pb-4 font-semibold text-[var(--text-secondary)] text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {backups.map((b, i) => (
                <tr key={i} className="hover:bg-[var(--bg-tertiary)] transition-colors">
                  <td className="py-4 flex items-center gap-3 text-[var(--text-primary)]">
                    <Clock className="w-4 h-4 text-[var(--text-secondary)]" />
                    {b.data}
                  </td>
                  <td className="py-4 text-[var(--text-secondary)]">{b.tamanho}</td>
                  <td className="py-4 text-[var(--text-secondary)]">{b.tipo}</td>
                  <td className="py-4 text-emerald-500 font-medium">{b.status}</td>
                  <td className="py-4 text-right flex items-center justify-end gap-3">
                    <button className="p-2 text-[var(--text-secondary)] hover:text-indigo-500 hover:bg-indigo-500/10 rounded-lg transition-colors" title="Download SQL">
                      <Download className="w-5 h-5" />
                    </button>
                    <button className="p-2 text-[var(--text-secondary)] hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-colors" title="Restaurar Banco">
                      <RotateCcw className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function CheckCircleIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
      <polyline points="22 4 12 14.01 9 11.01"></polyline>
    </svg>
  );
}
