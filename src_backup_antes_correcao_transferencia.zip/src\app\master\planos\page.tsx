'use client';
import React, { useState, useEffect } from 'react';
import { Package, Check, Star, Plus, Edit2, Trash2, X } from 'lucide-react';
import { getPlanosSaaS, salvarPlanoSaaS, deletarPlanoSaaS, PlanoSaaS } from '@/lib/saas/tenantManager';
import { formatarMoeda } from '@/lib/storage';

export default function PlanosPage() {
  const [planos, setPlanos] = useState<PlanoSaaS[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editPlano, setEditPlano] = useState<PlanoSaaS | null>(null);

  // Form states
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');
  const [preco, setPreco] = useState('');
  const [periodicidade, setPeriodicidade] = useState<'mensal' | 'anual' | 'semestral' | 'trimestral'>('mensal');
  const [limiteUsuarios, setLimiteUsuarios] = useState('');
  const [features, setFeatures] = useState('');
  const [ativo, setAtivo] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    carregarPlanos();
  }, []);

  async function carregarPlanos() {
    setLoading(true);
    try {
      const data = await getPlanosSaaS();
      setPlanos(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  const handleOpenModal = (plano?: PlanoSaaS) => {
    if (plano) {
      setEditPlano(plano);
      setNome(plano.nome);
      setDescricao(plano.descricao);
      setPreco(plano.preco.toString());
      setPeriodicidade(plano.periodicidade);
      setLimiteUsuarios(plano.limiteUsuarios.toString());
      setFeatures(plano.features.join('\n'));
      setAtivo(plano.ativo);
    } else {
      setEditPlano(null);
      setNome('');
      setDescricao('');
      setPreco('');
      setPeriodicidade('mensal');
      setLimiteUsuarios('0');
      setFeatures('');
      setAtivo(true);
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome || !preco) return alert('Preencha os campos obrigatórios');
    
    setSaving(true);
    try {
      const novoPlano: any = {
        nome,
        descricao,
        preco: parseFloat(preco),
        periodicidade,
        limiteUsuarios: parseInt(limiteUsuarios) || 0,
        features: features.split('\n').map(f => f.trim()).filter(f => f.length > 0),
        ativo
      };

      if (editPlano) {
        novoPlano.id = editPlano.id;
      }

      await salvarPlanoSaaS(novoPlano);
      setIsModalOpen(false);
      carregarPlanos();
    } catch (error) {
      console.error(error);
      alert('Erro ao salvar plano');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este plano? Esta ação não afetará clientes existentes, mas o plano não poderá mais ser vendido.')) return;
    try {
      await deletarPlanoSaaS(id);
      carregarPlanos();
    } catch (error) {
      console.error(error);
      alert('Erro ao excluir plano');
    }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 bg-gray-50 min-h-screen animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-gray-900 flex items-center gap-3">
            <Package className="w-8 h-8 text-blue-600" />
            Gestão de Planos
          </h1>
          <p className="text-gray-500 mt-1">Configure os pacotes, preços e limites oferecidos aos clientes SaaS.</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all shadow-md transform hover:-translate-y-0.5"
        >
          <Plus className="w-5 h-5" />
          Criar Novo Plano
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4 text-gray-500">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          Carregando planos...
        </div>
      ) : planos.length === 0 ? (
        <div className="bg-white border border-gray-200 rounded-2xl p-12 text-center shadow-sm">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Nenhum plano cadastrado</h3>
          <p className="text-gray-500 mb-6">Você ainda não possui planos de assinatura criados. Crie seu primeiro plano para poder vendê-lo aos clientes.</p>
          <button 
            onClick={() => handleOpenModal()}
            className="bg-blue-50 text-blue-600 font-bold py-2 px-6 rounded-lg border border-blue-200 hover:bg-blue-100 transition-colors"
          >
            Criar Primeiro Plano
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pt-4">
          {planos.map((p) => (
            <div key={p.id} className={`bg-white border rounded-2xl p-6 flex flex-col shadow-sm hover:shadow-md transition-all group ${!p.ativo ? 'opacity-75 border-gray-200 bg-gray-50' : 'border-gray-200'}`}>
              
              <div className="flex justify-between items-start mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white ${p.ativo ? 'bg-blue-600' : 'bg-gray-400'}`}>
                  <Package className="w-6 h-6" />
                </div>
                {!p.ativo && (
                  <span className="bg-gray-200 text-gray-600 text-xs font-bold px-2 py-1 rounded">INATIVO</span>
                )}
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">{p.nome}</h3>
              <p className="text-sm text-gray-500 mb-4 h-10">{p.descricao}</p>
              
              <div className="mb-6 pb-6 border-b border-gray-100">
                <span className="text-3xl font-black text-gray-900">{formatarMoeda(p.preco)}</span>
                <span className="text-gray-500">/{p.periodicidade}</span>
              </div>
              
              <ul className="space-y-3 mb-8 flex-1">
                <li className="flex items-center gap-3 text-sm text-gray-700">
                  <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span className="font-medium">{p.limiteUsuarios === 0 ? 'Usuários Ilimitados' : `Até ${p.limiteUsuarios} usuários`}</span>
                </li>
                {p.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-gray-600">
                    <Check className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <div className="flex gap-2 mt-auto">
                <button 
                  onClick={() => handleOpenModal(p)}
                  className="flex-1 py-2.5 rounded-xl font-bold transition-colors bg-gray-50 hover:bg-gray-100 border border-gray-200 text-gray-700 flex items-center justify-center gap-2"
                >
                  <Edit2 className="w-4 h-4" /> Editar
                </button>
                <button 
                  onClick={() => handleDelete(p.id)}
                  className="w-11 py-2.5 rounded-xl transition-colors bg-white hover:bg-red-50 border border-gray-200 text-gray-400 hover:text-red-600 hover:border-red-200 flex items-center justify-center"
                  title="Excluir"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-white/90 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-[0_8px_30px_rgb(0,0,0,0.12)] w-full max-w-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-300 border border-gray-200">
            <div className="flex justify-between items-center p-6 border-b border-gray-100 bg-gray-50/50">
              <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                <Package className="w-5 h-5 text-blue-600" />
                {editPlano ? 'Editar Plano' : 'Novo Plano SaaS'}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600 p-2 rounded-lg hover:bg-gray-100 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">Nome do Plano *</label>
                  <input 
                    type="text" required
                    value={nome} onChange={e => setNome(e.target.value)}
                    placeholder="Ex: Plano Pro"
                    className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">Preço (R$) *</label>
                  <input 
                    type="number" step="0.01" required
                    value={preco} onChange={e => setPreco(e.target.value)}
                    placeholder="Ex: 97.00"
                    className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">Periodicidade</label>
                  <select 
                    value={periodicidade} onChange={e => setPeriodicidade(e.target.value as any)}
                    className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  >
                    <option value="mensal">Mensal</option>
                    <option value="trimestral">Trimestral</option>
                    <option value="semestral">Semestral</option>
                    <option value="anual">Anual</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">Limite de Usuários</label>
                  <input 
                    type="number"
                    value={limiteUsuarios} onChange={e => setLimiteUsuarios(e.target.value)}
                    placeholder="Ex: 5 (Deixe 0 para ilimitado)"
                    className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">Descrição Curta</label>
                <input 
                  type="text" 
                  value={descricao} onChange={e => setDescricao(e.target.value)}
                  placeholder="Ex: Ideal para pequenas e médias empresas"
                  className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700 flex justify-between items-center">
                  <span>Recursos Incluídos (Features)</span>
                  <span className="text-xs text-gray-500 font-normal bg-gray-100 px-2 py-0.5 rounded-full">Um por linha</span>
                </label>
                <textarea 
                  rows={4}
                  value={features} onChange={e => setFeatures(e.target.value)}
                  placeholder="Módulo Financeiro Completo&#10;Suporte Prioritário&#10;Emissão de NF-e"
                  className="w-full bg-white border border-gray-300 text-gray-900 rounded-xl px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none resize-none leading-relaxed"
                />
              </div>

              <div className="flex items-center gap-3 bg-gray-50 p-4 rounded-xl border border-gray-200">
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer"
                    checked={ativo}
                    onChange={e => setAtivo(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500"></div>
                </label>
                <div>
                  <span className="text-sm font-bold text-gray-900 block">Plano Ativo (Disponível para venda)</span>
                  <span className="text-xs text-gray-500 block">Se desativado, não aparecerá na lista ao gerar novas cobranças.</span>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-gray-100 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 text-gray-600 font-semibold hover:bg-gray-100 rounded-xl transition-colors">
                  Cancelar
                </button>
                <button type="submit" disabled={saving} className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-md shadow-blue-500/20 flex items-center gap-2 disabled:opacity-50">
                  {saving ? 'Salvando...' : 'Salvar Plano'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
