'use client';
import React from 'react';
import { Shield, Key, AlertTriangle, Eye, Lock } from 'lucide-react';

export default function SegurancaPage() {
  const logs = [
    { tenant: 'Empresa A', user: 'admin@empresaA.com', action: 'Tentativa de login falha', ip: '189.45.12.9', time: '10:45', alert: true },
    { tenant: 'Master', user: 'Super Admin', action: 'Alteração em plano Pro', ip: '192.168.1.100', time: '09:30', alert: false },
    { tenant: 'Empresa B', user: 'joao@empresaB.com', action: 'Exportação de 5.000 lançamentos', ip: '177.89.33.1', time: 'Ontem', alert: true },
    { tenant: 'Empresa C', user: 'maria@empresaC.com', action: 'Login com sucesso', ip: '200.15.44.2', time: 'Ontem', alert: false },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700 min-w-0">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">Segurança e Auditoria</h1>
          <p className="text-[var(--text-secondary)] mt-1">Logs de acesso globais e configurações de segurança.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium">
          <Key className="w-4 h-4" /> Gerar Chave de API Global
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)]">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-6 h-6 text-emerald-500" />
            <h3 className="font-bold text-[var(--text-primary)]">Status WAF</h3>
          </div>
          <p className="text-2xl font-black text-[var(--text-primary)]">Ativo</p>
          <p className="text-xs text-[var(--text-secondary)]">Bloqueando tráfego malicioso</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)]">
          <div className="flex items-center gap-3 mb-2">
            <Lock className="w-6 h-6 text-indigo-500" />
            <h3 className="font-bold text-[var(--text-primary)]">Autenticação 2FA</h3>
          </div>
          <p className="text-2xl font-black text-[var(--text-primary)]">Forçada</p>
          <p className="text-xs text-[var(--text-secondary)]">Para todos os administradores</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)]">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-6 h-6 text-red-500" />
            <h3 className="font-bold text-[var(--text-primary)]">Ameaças Bloqueadas</h3>
          </div>
          <p className="text-2xl font-black text-[var(--text-primary)]">1,248</p>
          <p className="text-xs text-[var(--text-secondary)]">Últimos 7 dias</p>
        </div>
      </div>

      <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] overflow-hidden">
        <h2 className="text-lg font-bold text-[var(--text-primary)] mb-6">Logs de Atividade Global (Tempo Real)</h2>
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left min-w-[800px]">
            <thead className="bg-[var(--bg-secondary)] border-b border-[var(--border)]">
              <tr>
                <th className="p-4 text-xs font-semibold text-[var(--text-secondary)] uppercase">Horário</th>
                <th className="p-4 text-xs font-semibold text-[var(--text-secondary)] uppercase">Tenant / Usuário</th>
                <th className="p-4 text-xs font-semibold text-[var(--text-secondary)] uppercase">Ação Realizada</th>
                <th className="p-4 text-xs font-semibold text-[var(--text-secondary)] uppercase">Endereço IP</th>
                <th className="p-4 text-xs font-semibold text-[var(--text-secondary)] uppercase text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border)]">
              {logs.map((l, i) => (
                <tr key={i} className={`hover:bg-[var(--bg-tertiary)] transition-colors ${l.alert ? 'bg-red-500/5' : ''}`}>
                  <td className="p-4 text-sm text-[var(--text-secondary)]">{l.time}</td>
                  <td className="p-4">
                    <p className="text-sm font-semibold text-[var(--text-primary)]">{l.tenant}</p>
                    <p className="text-xs text-[var(--text-secondary)]">{l.user}</p>
                  </td>
                  <td className="p-4 text-sm text-[var(--text-primary)] flex items-center gap-2">
                    {l.alert && <AlertTriangle className="w-4 h-4 text-red-500" />}
                    {l.action}
                  </td>
                  <td className="p-4 text-sm font-mono text-[var(--text-secondary)]">{l.ip}</td>
                  <td className="p-4 text-right">
                    <button className="text-indigo-500 hover:text-indigo-400 text-sm font-medium">Ver Detalhes</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
