import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ResumoExtratoPDF {
  totalEntradas: number;
  totalSaidas: number;
  saldoFinal: number;
  contaNome: string;
  periodo: string;
}

export function gerarPDFExtrato(transacoes: any[], resumo: ResumoExtratoPDF) {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const redPrimary = [204, 0, 0];
  const greenPrimary = [21, 128, 61];
  const redDark = [139, 0, 0];
  const textDark = [44, 44, 44];
  const textMuted = [120, 120, 120];

  // 1. BARRA SUPERIOR EM VERMELHO PREMIUM
  doc.setFillColor(redPrimary[0], redPrimary[1], redPrimary[2]);
  doc.rect(0, 0, 210, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('SISTEMA FINANCEIRO ERP | EXTRATO CONSOLIDADO', 14, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.text('PADRÃO BANCÁRIO OFICIAL', 196, 15, { align: 'right' });

  // 2. METADADOS E CABEÇALHO
  doc.setTextColor(textDark[0], textDark[1], textDark[2]);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(`Demonstrativo da Conta: ${resumo.contaNome}`, 14, 34);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(textMuted[0], textMuted[1], textMuted[2]);
  const dataHoje = new Date().toLocaleString('pt-BR');
  doc.text(`Emissão: ${dataHoje} | Período: ${resumo.periodo}`, 14, 40);

  // 3. CARDS DE RESUMO FINANCEIRO SUPERIOR
  // Card Entradas (VERDE)
  doc.setFillColor(240, 253, 244);
  doc.roundedRect(14, 46, 56, 18, 3, 3, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(21, 128, 61);
  doc.text('ENTRADAS CONFIRMADAS', 18, 52);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(21, 128, 61);
  doc.text(`+ R$ ${resumo.totalEntradas.toFixed(2).replace('.', ',')}`, 18, 59);

  // Card Saídas (VERMELHO)
  doc.setFillColor(254, 242, 242);
  doc.roundedRect(77, 46, 56, 18, 3, 3, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(139, 0, 0);
  doc.text('SAÍDAS E DÉBITOS', 81, 52);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(139, 0, 0);
  doc.text(`- R$ ${resumo.totalSaidas.toFixed(2).replace('.', ',')}`, 81, 59);

  // Card Saldo Final (VERDE SE >= 0, VERMELHO SE < 0)
  const isPositivo = resumo.saldoFinal >= 0;
  const corSaldo = isPositivo ? greenPrimary : redDark;
  doc.setFillColor(isPositivo ? 240 : 254, isPositivo ? 253 : 242, isPositivo ? 244 : 242);
  doc.roundedRect(140, 46, 56, 18, 3, 3, 'F');
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(corSaldo[0], corSaldo[1], corSaldo[2]);
  doc.text('RESULTADO DO EXTRATO', 144, 52);
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(corSaldo[0], corSaldo[1], corSaldo[2]);
  doc.text(`R$ ${resumo.saldoFinal.toFixed(2).replace('.', ',')}`, 144, 59);

  // 4. TABELA DE MOVIMENTAÇÕES COLORIDAS
  const tableData = transacoes.map(t => {
    const isCredito = t.tipo === 'receita' || (t.tipo === 'transferencia' && t.impacto > 0);
    const sinal = isCredito ? '+' : '-';
    return [
      t.data.split('-').reverse().join('/'),
      t.descricao,
      t.categoriaNome || t.tipo,
      t.contaNome || '—',
      `${sinal} R$ ${t.valor.toFixed(2).replace('.', ',')}`,
      `R$ ${(t.saldoApos || 0).toFixed(2).replace('.', ',')}`
    ];
  });

  autoTable(doc, {
    startY: 70,
    head: [['Data', 'Histórico / Descrição', 'Categoria', 'Conta', 'Valor', 'Saldo Acumulado']],
    body: tableData,
    theme: 'striped',
    headStyles: {
      fillColor: [204, 0, 0],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 9,
      halign: 'left'
    },
    styles: {
      fontSize: 8.5,
      cellPadding: 3.5,
      textColor: [44, 44, 44]
    },
    columnStyles: {
      0: { cellWidth: 22 },
      1: { cellWidth: 55 },
      2: { cellWidth: 32 },
      3: { cellWidth: 28 },
      4: { cellWidth: 25, halign: 'right', fontStyle: 'bold' },
      5: { cellWidth: 26, halign: 'right', fontStyle: 'bold' }
    },
    didParseCell: (data) => {
      // Colorir a coluna de Valor não PDF: Verde para Receitas (+), Vermelho para Despesas (-)
      if (data.section === 'body' && data.column.index === 4) {
        const text = data.cell.raw as string;
        if (text && text.startsWith('+')) {
          data.cell.styles.textColor = [21, 128, 61]; // VERDE ESCURO RECEITA
        } else {
          data.cell.styles.textColor = [139, 0, 0]; // VERMELHO ESCURO DESPESA
        }
      }
    },
    didDrawPage: (data) => {
      // Rodapé em todas as páginas
      const totalPages = (doc as any).internal.getNumberOfPages();
      doc.setFontSize(8);
      doc.setTextColor(150, 150, 150);
      doc.text(`Página ${data.pageNumber} de ${totalPages}`, 196, 287, { align: 'right' });
      doc.text('Documento oficial emitido pelo Sistema Financeiro ERP | Autenticidade Garantida', 14, 287);
    }
  });

  // 5. TOTALIZADORES CONSOLIDADOS NO FINAL DO EXTRATO
  const finalY = (doc as any).lastAutoTable.finalY + 10;
  if (finalY < 250) {
    doc.setFillColor(248, 250, 252);
    doc.roundedRect(14, finalY, 182, 28, 4, 4, 'F');
    doc.setDrawColor(204, 0, 0);
    doc.rect(14, finalY, 182, 28, 'S');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(204, 0, 0);
    doc.text('QUADRO DE TOTALIZADORES FINAIS DO EXTRATO BANCÁRIO', 18, finalY + 7);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(21, 128, 61);
    doc.text(`(+) TOTAL RECEITAS / ENTRADAS: R$ ${resumo.totalEntradas.toFixed(2).replace('.', ',')}`, 18, finalY + 14);

    doc.setTextColor(139, 0, 0);
    doc.text(`(-) TOTAL DESPESAS / SAÍDAS: R$ ${resumo.totalSaidas.toFixed(2).replace('.', ',')}`, 18, finalY + 20);

    doc.setTextColor(isPositivo ? 21 : 139, isPositivo ? 128 : 0, isPositivo ? 61 : 0);
    doc.text(`(=) RESULTADO FINAL DO EXTRATO: R$ ${resumo.saldoFinal.toFixed(2).replace('.', ',')}`, 18, finalY + 26);
  }

  doc.save(`extrato-bancario-${new Date().toISOString().split('T')[0]}.pdf`);
}
