export const AUTOCRED_CONFIG = {
  tenantId: 'autocred-promotora-de-credito',
  nomeFantasia: 'Autocred Promotora de Crédito',
  nomeSistema: 'Autocred Promotora',
  logoUrl: '/autocred-icon.png',
  faviconUrl: '/autocred-favicon.ico',
  corPrincipal: '#0284c7',
  corHover: '#0369a1',
  headerGradient: 'linear-gradient(135deg, #0284c7 0%, #0369a1 100%)',
};
