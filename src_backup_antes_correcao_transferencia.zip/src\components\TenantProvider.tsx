'use client';

import { useEffect, useState } from 'react';
import { getTenantByHostname, LicencaMaster } from '@/lib/saas/tenantManager';
import { setTenantId } from '@/lib/storage';

export function TenantProvider({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [tenant, setTenant] = useState<LicencaMaster | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadTenant() {
      try {
        const hostname = window.location.hostname;
        const pathname = window.location.pathname;
        const searchParams = new URLSearchParams(window.location.search);
        const forceTenant = searchParams.get('tenant');
        
        // Ignorar em ambiente de desenvolvimento local caso não usemos hosts virtuais, 
        // ou se for a rota Master Administrativa (salvo se tiver o forceTenant)
        if (!forceTenant && (hostname === 'localhost' || hostname === '127.0.0.1' || pathname.startsWith('/master'))) {
          // Mantém null para default, ou pode injetar um tenant de teste 'local-dev'
          setLoading(false);
          return;
        }

        const domainToSearch = forceTenant || hostname;
        const t = await getTenantByHostname(domainToSearch);
        
        if (t) {
          if (t.status === 'inadimplente' || t.status === 'suspensa') {
            setError(`Esta licença encontra-se ${t.status}. Entre em contato com o suporte.`);
          } else {
            setTenantId(t.id);
            setTenant(t);
          }
        } else {
          // Se não encontrou o tenant, e não é um domínio base do sistema, mostrar erro
          if (!hostname.includes('sistemafinanceiropessoal.vercel.app')) {
             setError('Licença não encontrada para este domínio.');
          }
        }
      } catch (e) {
        console.error('Erro ao carregar tenant', e);
      } finally {
        setLoading(false);
      }
    }

    loadTenant();
  }, []);

  useEffect(() => {
    const isAutocredTenant = tenant?.id === 'autocred-promotora-de-credito' || (typeof window !== 'undefined' && window.location.search.includes('tenant=autocred-promotora-de-credito'));

    const updateFavicon = (href: string) => {
      let existingLinks = document.querySelectorAll<HTMLLinkElement>("link[rel*='icon']");
      if (existingLinks.length > 0) {
        existingLinks.forEach(link => {
          link.href = href;
        });
      } else {
        const newLink = document.createElement('link');
        newLink.rel = 'shortcut icon';
        newLink.href = href;
        document.head.appendChild(newLink);
      }
    };

    if (isAutocredTenant) {
      document.title = tenant?.nomeFantasia || 'Autocred Promotora de Crédito';
      const iconUrl = `/autocred-icon.png?v=${Date.now()}`;
      const manifestUrl = '/api/manifest?tenant=autocred-promotora-de-credito';

      updateFavicon(iconUrl);

      let manifestLink = document.querySelector<HTMLLinkElement>("link[rel='manifest']");
      if (manifestLink) {
        manifestLink.href = manifestUrl;
      } else {
        manifestLink = document.createElement('link');
        manifestLink.rel = 'manifest';
        manifestLink.href = manifestUrl;
        document.head.appendChild(manifestLink);
      }
    } else {
      document.title = 'FinPessoal Master — Sistema Financeiro ERP Pro';
      const iconUrl = '/icon.svg';
      const manifestUrl = '/api/manifest';

      updateFavicon(iconUrl);

      let manifestLink = document.querySelector<HTMLLinkElement>("link[rel='manifest']");
      if (manifestLink) {
        manifestLink.href = manifestUrl;
      }
    }
  }, [tenant]);

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[var(--bg-primary)]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--primary)]"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[var(--bg-primary)] p-4 text-center">
        <div className="max-w-md p-8 glass-panel border border-red-500/30 rounded-2xl shadow-xl">
          <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold mb-2 text-[var(--text-primary)]">Acesso Bloqueado</h2>
          <p className="text-[var(--text-secondary)]">{error}</p>
        </div>
      </div>
    );
  }

  const isAutocred = (typeof window !== 'undefined' && window.location.search.includes('tenant=autocred-promotora-de-credito')) || tenant?.id === 'autocred-promotora-de-credito';
  const tenantColor = isAutocred ? '#0284c7' : tenant?.configuracoes?.corPrincipal;

  return (
    <>
      {isAutocred && (
        <style dangerouslySetInnerHTML={{
          __html: `
            :root {
              --primary: #0284c7 !important;
              --primary-hover: #0369a1 !important;
            }
            .bank-app-header {
              background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
              box-shadow: 0 4px 20px rgba(2, 132, 199, 0.4), inset 0 -1px 0 rgba(255, 255, 255, 0.15) !important;
            }
            [data-theme='dark'] .bank-app-header {
              background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%) !important;
              box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5) !important;
            }
          `
        }} />
      )}
      {!isAutocred && tenantColor && (
        <style dangerouslySetInnerHTML={{
          __html: `
            :root {
              --primary: ${tenantColor};
            }
          `
        }} />
      )}
      {children}
    </>
  );
}
