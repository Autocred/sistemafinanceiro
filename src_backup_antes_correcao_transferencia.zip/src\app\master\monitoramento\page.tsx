'use client';
import React from 'react';
import { Server, Cpu, HardDrive, Network, Activity } from 'lucide-react';

export default function MonitoramentoPage() {
  const servers = [
    { name: 'App Node 01 (SP)', cpu: 45, ram: 78, status: 'Normal' },
    { name: 'App Node 02 (SP)', cpu: 32, ram: 65, status: 'Normal' },
    { name: 'Worker Jobs 01', cpu: 89, ram: 54, status: 'Alto Uso' },
    { name: 'Banco de Dados (Master)', cpu: 60, ram: 88, status: 'Alerta' },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-700 min-w-0">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">Monitoramento da Infraestrutura</h1>
          <p className="text-[var(--text-secondary)] mt-1">Status dos servidores e consumo de recursos.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] border-l-4 border-l-emerald-500">
          <div className="flex items-center gap-3 mb-1">
            <Server className="w-5 h-5 text-[var(--text-secondary)]" />
            <span className="text-sm font-semibold text-[var(--text-secondary)]">Uptime Global</span>
          </div>
          <p className="text-3xl font-bold text-[var(--text-primary)]">99.99%</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] border-l-4 border-l-indigo-500">
          <div className="flex items-center gap-3 mb-1">
            <Activity className="w-5 h-5 text-[var(--text-secondary)]" />
            <span className="text-sm font-semibold text-[var(--text-secondary)]">Tempo de Resposta</span>
          </div>
          <p className="text-3xl font-bold text-[var(--text-primary)]">142ms</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] border-l-4 border-l-blue-500">
          <div className="flex items-center gap-3 mb-1">
            <Network className="w-5 h-5 text-[var(--text-secondary)]" />
            <span className="text-sm font-semibold text-[var(--text-secondary)]">Tráfego de Rede</span>
          </div>
          <p className="text-3xl font-bold text-[var(--text-primary)]">1.2 TB</p>
        </div>
        <div className="glass-panel p-6 rounded-2xl border border-[var(--border)] border-l-4 border-l-purple-500">
          <div className="flex items-center gap-3 mb-1">
            <HardDrive className="w-5 h-5 text-[var(--text-secondary)]" />
            <span className="text-sm font-semibold text-[var(--text-secondary)]">Armazenamento</span>
          </div>
          <p className="text-3xl font-bold text-[var(--text-primary)]">850 GB</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {servers.map((s, i) => (
          <div key={i} className="glass-panel p-6 rounded-2xl border border-[var(--border)]">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-[var(--text-primary)]">{s.name}</h3>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                s.status === 'Normal' ? 'bg-emerald-500/10 text-emerald-500' :
                s.status === 'Alerta' ? 'bg-amber-500/10 text-amber-500' :
                'bg-red-500/10 text-red-500'
              }`}>
                {s.status}
              </span>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[var(--text-secondary)] flex items-center gap-1"><Cpu className="w-4 h-4"/> CPU</span>
                  <span className="font-mono text-[var(--text-primary)]">{s.cpu}%</span>
                </div>
                <div className="w-full bg-[var(--bg-tertiary)] rounded-full h-2">
                  <div className={`h-2 rounded-full ${s.cpu > 80 ? 'bg-red-500' : 'bg-indigo-500'}`} style={{ width: `${s.cpu}%` }}></div>
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-[var(--text-secondary)] flex items-center gap-1"><HardDrive className="w-4 h-4"/> RAM</span>
                  <span className="font-mono text-[var(--text-primary)]">{s.ram}%</span>
                </div>
                <div className="w-full bg-[var(--bg-tertiary)] rounded-full h-2">
                  <div className={`h-2 rounded-full ${s.ram > 80 ? 'bg-red-500' : 'bg-purple-500'}`} style={{ width: `${s.ram}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
