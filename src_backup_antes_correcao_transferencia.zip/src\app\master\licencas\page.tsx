'use client';
import React, { useState, useEffect } from 'react';
import { getDb } from '@/lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { LicencaMaster } from '@/lib/saas/tenantManager';
import ModalProvisionamento from './ModalProvisionamento';
import Link from 'next/link';
import { ExternalLink, Plus, Search, Edit3, Trash2, Shield, Calendar, Users, Building2, MoreHorizontal, Filter, Copy } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function LicencasMaster() {
  const [licencas, setLicencas] = useState<LicencaMaster[]>([]);
  const [loading, setLoading] = useState(true);
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<string>('todas');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const router = useRouter();

  useEffect(() => {
    const q = query(collection(getDb(), 'admin_master_licencas'), orderBy('dataCriacao', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snap) => {
      const lista = snap.docs.map(d => {
        const data = d.data();
        
        let dataCriacao = new Date();
        if (data.dataCriacao) {
          if (typeof data.dataCriacao.toDate === 'function') dataCriacao = data.dataCriacao.toDate();
          else dataCriacao = new Date(data.dataCriacao);
        }
        
        let dataVencimento = null;
        if (data.dataVencimento) {
          if (typeof data.dataVencimento.toDate === 'function') dataVencimento = data.dataVencimento.toDate();
          else dataVencimento = new Date(data.dataVencimento);
        }

        return {
          id: d.id,
          ...data,
          nomeFantasia: data.nomeFantasia || 'Sem Nome',
          dominio: data.dominio || '',
          documento: data.documento || '',
          dataCriacao,
          dataVencimento,
        };
      }) as LicencaMaster[];
      
      setLicencas(lista);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const licencasFiltradas = licencas.filter(l => {
    const nome = String(l.nomeFantasia || '').toLowerCase();
    const dom = String(l.dominio || '').toLowerCase();
    const docStr = String(l.documento || '');
    const term = String(busca || '').toLowerCase();

    const matchBusca = nome.includes(term) || dom.includes(term) || docStr.includes(term);
      
    if (filtroStatus === 'todas') return matchBusca;
    return matchBusca && l.status === filtroStatus;
  });

  const getStatusBadge = (status: any) => {
    const s = String(status || '').toLowerCase();
    switch (s) {
      case 'ativa': return <span className="px-2.5 py-1 bg-emerald-50 text-emerald-600 border border-emerald-200 rounded-lg text-xs font-bold uppercase tracking-wider">Ativa</span>;
      case 'suspensa': return <span className="px-2.5 py-1 bg-red-50 text-red-600 border border-red-200 rounded-lg text-xs font-bold uppercase tracking-wider">Suspensa</span>;
      case 'inadimplente': return <span className="px-2.5 py-1 bg-amber-50 text-amber-600 border border-amber-200 rounded-lg text-xs font-bold uppercase tracking-wider">Inadimplente</span>;
      case 'teste': return <span className="px-2.5 py-1 bg-blue-50 text-blue-600 border border-blue-200 rounded-lg text-xs font-bold uppercase tracking-wider">Teste</span>;
      default: return <span className="px-2.5 py-1 bg-gray-100 text-gray-600 border border-gray-200 rounded-lg text-xs font-bold uppercase tracking-wider">{s || 'Desconhecido'}</span>;
    }
  };

  return (
    <div className="p-6 md:p-8 max-w-7xl mx-auto space-y-8 bg-gray-50 min-h-screen animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-gray-900 flex items-center gap-3">
            <Shield className="w-8 h-8 text-blue-600" />
            Clientes e Licenças
          </h1>
          <p className="text-gray-500 mt-1">Gerencie os clientes SaaS, domínios e assinaturas do sistema.</p>
        </div>
        
        <button 
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2.5 px-5 rounded-xl transition-all shadow-md transform hover:-translate-y-0.5"
        >
          <Plus className="w-5 h-5" />
          Novo Cliente
        </button>
      </div>

      {/* TABS E ESTATÍSTICAS RÁPIDAS */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-sm">
          <p className="text-sm font-bold text-gray-500 uppercase">Total</p>
          <p className="text-2xl font-black text-gray-900">{licencas.length}</p>
        </div>
        <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-sm">
          <p className="text-sm font-bold text-gray-500 uppercase">Ativos</p>
          <p className="text-2xl font-black text-emerald-600">{licencas.filter(l => l.status === 'ativa').length}</p>
        </div>
        <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-sm">
          <p className="text-sm font-bold text-gray-500 uppercase">Inadimplentes</p>
          <p className="text-2xl font-black text-amber-600">{licencas.filter(l => l.status === 'inadimplente').length}</p>
        </div>
        <div className="bg-white border border-gray-200 p-4 rounded-xl shadow-sm">
          <p className="text-sm font-bold text-gray-500 uppercase">Suspensos</p>
          <p className="text-2xl font-black text-red-600">{licencas.filter(l => l.status === 'suspensa').length}</p>
        </div>
      </div>

      {/* FILTER AREA */}
      <div className="bg-white border border-gray-200 rounded-2xl p-5 flex flex-col md:flex-row gap-4 items-center justify-between shadow-sm">
        <div className="relative w-full md:w-[400px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Buscar por cliente, domínio ou CNPJ..."
            value={busca}
            onChange={e => setBusca(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 text-gray-900 placeholder-gray-400 rounded-xl pl-10 pr-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-medium"
          />
        </div>
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-2 text-sm text-gray-500 font-semibold bg-gray-50 px-3 py-2.5 border border-gray-200 rounded-xl">
            <Filter className="w-4 h-4" />
            Status:
            <select 
              value={filtroStatus}
              onChange={e => setFiltroStatus(e.target.value)}
              className="bg-transparent border-none outline-none font-bold text-gray-900 cursor-pointer"
            >
              <option value="todas">Todas</option>
              <option value="ativa">Ativas</option>
              <option value="inadimplente">Inadimplentes</option>
              <option value="suspensa">Suspensas</option>
            </select>
          </div>
        </div>
      </div>

      {/* DATAGRID / TABLE */}
      <div className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-sm flex flex-col min-h-[400px]">
        <div className="overflow-x-auto flex-1 custom-scrollbar">
          <table className="w-full text-left text-sm">
            <thead className="bg-gray-50 border-b border-gray-200 text-gray-600">
              <tr>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Cliente</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Plano</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Vencimento</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs">Status</th>
                <th className="px-6 py-4 font-semibold uppercase tracking-wider text-xs text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 bg-white">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center">
                    <div className="flex flex-col items-center justify-center gap-3">
                      <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
                      <span className="text-gray-500 font-medium">Carregando licenças...</span>
                    </div>
                  </td>
                </tr>
              ) : licencasFiltradas.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center">
                    <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-500 font-medium text-lg">Nenhum cliente encontrado.</p>
                  </td>
                </tr>
              ) : (
                licencasFiltradas.map((l) => (
                  <tr key={l.id} className="hover:bg-gray-50 transition-colors group">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center border border-gray-200 shrink-0">
                          <Building2 className="w-5 h-5 text-gray-500" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{l.nomeFantasia}</p>
                          <span className="text-xs text-gray-500 font-semibold flex items-center gap-1 mt-0.5">
                            {l.dominio}
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-purple-700 font-bold uppercase text-xs bg-purple-50 px-2 py-1 rounded-md border border-purple-200">{l.plano || 'Sem Plano'}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-gray-700 font-medium">
                        <Calendar className="w-4 h-4 text-gray-400" />
                        {l.dataVencimento ? l.dataVencimento.toLocaleDateString('pt-BR') : '-'}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getStatusBadge(l.status)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => {
                            const link = l.dominio.includes('localhost') ? `http://localhost:3000/?tenant=${l.dominio}` : `https://${l.dominio}.financeiro.vercel.app`;
                            navigator.clipboard.writeText(link);
                            alert('Link copiado: ' + link);
                          }}
                          className="bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 py-1.5 px-2 rounded-lg text-sm font-semibold transition-all shadow-sm"
                          title="Copiar Link"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => {
                             localStorage.setItem('impersonate_user', 'true');
                             localStorage.setItem('impersonate_tenantId', l.id);
                             window.location.href = '/';
                          }}
                          className="bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 py-1.5 px-3 rounded-lg text-sm font-semibold transition-all shadow-sm flex items-center gap-1.5"
                          title="Acessar sistema como este cliente"
                        >
                          <ExternalLink className="w-4 h-4" />
                          Acessar
                        </button>
                        <button 
                          onClick={() => router.push(`/master/licencas/${l.id}`)}
                          className="bg-white hover:bg-gray-50 border border-gray-200 text-gray-700 py-1.5 px-3 rounded-lg text-sm font-semibold transition-all shadow-sm flex items-center gap-1.5"
                        >
                          Detalhes
                        </button>
                        <button 
                          onClick={async () => {
                            if(confirm(`ATENÇÃO: A exclusão do cliente ${l.nomeFantasia} é permanente (Hard Delete) e removerá todos os dados do banco isolado. Confirmar?`)) {
                               const { deleteDoc, doc } = await import('firebase/firestore');
                               const { getDb } = await import('@/lib/firebase');
                               const db = getDb();
                               try {
                                 // Aqui removemos a licença mestre
                                 await deleteDoc(doc(db, 'admin_master_licencas', l.id));
                                 // (Em um backend real, removeríamos a coleção tenants/id)
                                 alert('Licença e banco de dados removidos com sucesso.');
                               } catch (err) {
                                 alert('Erro ao excluir.');
                               }
                            }
                          }}
                          className="bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 py-1.5 px-2 rounded-lg text-sm font-semibold transition-all shadow-sm"
                          title="Excluir Permanentemente"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <ModalProvisionamento 
          onClose={() => setIsModalOpen(false)}
          onSucesso={() => {
            setIsModalOpen(false);
          }}
        />
      )}
    </div>
  );
}
