import type { Metadata, Viewport } from 'next';
import './globals.css';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export const metadata: Metadata = {
  title: 'Sistema Financeiro ERP Pro — Padrão Bancário Premium',
  description: 'Gerencie suas finanças com inteligência artificial, extrato bancário oficial, relatórios em PDF e padrão ERP Premium.',
  keywords: 'finanças pessoais, controle financeiro, inteligência artificial, gestão de despesas, erp financeiro',
  manifest: '/api/manifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black-translucent',
    title: 'Financeiro ERP',
  },
  icons: {
    icon: '/icon.svg',
    apple: '/icon.svg',
  }
};

export const viewport: Viewport = {
  themeColor: '#cc092f',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
};

import { TenantProvider } from '@/components/TenantProvider';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <meta charSet="utf-8" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta httpEquiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
        <meta httpEquiv="Pragma" content="no-cache" />
        <meta httpEquiv="Expires" content="0" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/icon.svg" />
        <script dangerouslySetInnerHTML={{ __html: `
          (function() {
            try {
              var t = localStorage.getItem('theme_preference') || 'light';
              document.documentElement.setAttribute('data-theme', t);
            } catch(e){}
            
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js').then(function(registration) {
                  console.log('ServiceWorker registration successful with scope: ', registration.scope);
                }, function(err) {
                  console.log('ServiceWorker registration failed: ', err);
                });
              });
            }
          })();
        ` }} />
      </head>
      <body suppressHydrationWarning>
        <TenantProvider>
          {children}
        </TenantProvider>
      </body>
    </html>
  );
}
